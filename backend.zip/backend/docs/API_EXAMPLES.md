# API Examples - Hostel Management System

This document provides comprehensive examples for all API endpoints using both cURL commands and Postman collection format.

## 📋 Table of Contents

1. [Authentication Examples](#authentication-examples)
2. [Student Management Examples](#student-management-examples)
3. [Warden Management Examples](#warden-management-examples)
4. [Room Management Examples](#room-management-examples)
5. [Gate Pass Examples](#gate-pass-examples)
6. [Complaint Examples](#complaint-examples)
7. [Fine Management Examples](#fine-management-examples)
8. [Payment Examples](#payment-examples)
9. [Postman Collection](#postman-collection)

---

## 🔐 Authentication Examples

### 1. Register a Student

**cURL:**
```bash
curl -X POST http://localhost:3000/api/auth/register/student \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john_doe",
    "email": "john.doe@university.edu",
    "password": "SecurePass123",
    "role": "student",
    "firstName": "John",
    "lastName": "Doe",
    "studentId": "STU007",
    "course": "Computer Science",
    "year": 2,
    "phone": "+1234567890"
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "student registered successfully",
  "data": {
    "user": {
      "id": "uuid-here",
      "username": "john_doe",
      "email": "john.doe@university.edu",
      "role": "student",
      "firstName": "John",
      "lastName": "Doe",
      "isActive": true,
      "createdAt": "2024-01-15T10:00:00.000Z",
      "updatedAt": "2024-01-15T10:00:00.000Z"
    },
    "token": "jwt-token-here"
  },
  "errors": []
}
```

### 2. Register a Warden

**cURL:**
```bash
curl -X POST http://localhost:3000/api/auth/register/warden \
  -H "Content-Type: application/json" \
  -d '{
    "username": "warden_jane",
    "email": "jane.warden@hostel.com",
    "password": "WardenPass123",
    "role": "warden",
    "firstName": "Jane",
    "lastName": "Smith",
    "employeeId": "EMP004",
    "department": "Administration",
    "phone": "+1234567891"
  }'
```

### 3. Login

**cURL:**
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice.student@university.edu",
    "password": "student123"
  }'
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": "uuid-here",
      "username": "alice_student",
      "email": "alice.student@university.edu",
      "role": "student",
      "firstName": "Alice",
      "lastName": "Johnson",
      "isActive": true
    },
    "profile": {
      "id": "uuid-here",
      "userId": "uuid-here",
      "studentId": "STU001",
      "course": "Computer Science",
      "year": 2,
      "phone": "+1234567893",
      "roomId": "room-uuid",
      "isActive": true
    },
    "token": "jwt-token-here"
  },
  "errors": []
}
```

### 4. Get Profile

**cURL:**
```bash
curl -X GET http://localhost:3000/api/auth/profile \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 5. Update Profile

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/auth/profile \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "firstName": "Alice",
    "lastName": "Johnson-Smith",
    "phone": "+1234567899"
  }'
```

### 6. Change Password

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/auth/change-password \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{
    "currentPassword": "student123",
    "newPassword": "NewSecurePass123"
  }'
```

---

## 👨‍🎓 Student Management Examples

### 1. Get All Students (Warden Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/students?page=1&limit=10&search=alice" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 2. Get Student by ID

**cURL:**
```bash
curl -X GET http://localhost:3000/api/students/STUDENT_ID \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 3. Get My Profile (Student Only)

**cURL:**
```bash
curl -X GET http://localhost:3000/api/students/my-profile \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

### 4. Update Student (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/students/STUDENT_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "course": "Engineering",
    "year": 3,
    "roomId": "ROOM_ID"
  }'
```

### 5. Get Student Statistics (Warden Only)

**cURL:**
```bash
curl -X GET http://localhost:3000/api/students/stats \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

---

## 👨‍💼 Warden Management Examples

### 1. Get All Wardens

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/wardens?page=1&limit=10" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 2. Get Warden Dashboard

**cURL:**
```bash
curl -X GET http://localhost:3000/api/wardens/dashboard \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 3. Get My Profile

**cURL:**
```bash
curl -X GET http://localhost:3000/api/wardens/my-profile \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 4. Update Warden Profile

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/wardens/WARDEN_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "department": "Security",
    "phone": "+1234567899"
  }'
```

---

## 🏠 Room Management Examples

### 1. Get All Rooms

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/rooms?page=1&limit=10&building=Block A&available=true" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

### 2. Create Room (Warden Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/rooms \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "roomNumber": "105",
    "building": "Block A",
    "capacity": 2,
    "floor": 1,
    "roomType": "double",
    "rent": 5500,
    "amenities": ["WiFi", "Air Conditioning", "Study Table"]
  }'
```

### 3. Update Room (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/rooms/ROOM_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "capacity": 3,
    "rent": 4500,
    "amenities": ["WiFi", "Air Conditioning", "Study Table", "Refrigerator"]
  }'
```

### 4. Assign Student to Room (Warden Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/rooms/ROOM_ID/assign \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "studentId": "STUDENT_ID"
  }'
```

### 5. Get Room Statistics (Warden Only)

**cURL:**
```bash
curl -X GET http://localhost:3000/api/rooms/stats \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

---

## 🚪 Gate Pass Examples

### 1. Create Gate Pass (Student Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/gatepasses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "reason": "Going home for weekend to visit family",
    "destination": "New York",
    "departureTime": "2024-01-20T10:00:00Z",
    "expectedReturnTime": "2024-01-22T18:00:00Z",
    "emergencyContact": "+1234567890"
  }'
```

### 2. Get My Gate Passes (Student Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/gatepasses/my-passes?page=1&limit=10&status=pending" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

### 3. Get All Gate Passes (Warden Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/gatepasses?page=1&limit=10&status=pending" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 4. Approve Gate Pass (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/gatepasses/GATEPASS_ID/approve \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 5. Reject Gate Pass (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/gatepasses/GATEPASS_ID/reject \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "rejectionReason": "Insufficient reason provided for the gate pass request"
  }'
```

### 6. Mark Gate Pass as Returned (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/gatepasses/GATEPASS_ID/return \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "actualReturnTime": "2024-01-22T17:30:00Z"
  }'
```

### 7. Cancel Gate Pass (Student Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/gatepasses/GATEPASS_ID/cancel \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

---

## 📝 Complaint Examples

### 1. Create Complaint (Student Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/complaints \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "subject": "WiFi not working in my room",
    "description": "The WiFi connection in room 201 has been very poor for the past week. I cannot access online classes properly and it affects my studies.",
    "category": "maintenance",
    "priority": "high"
  }'
```

### 2. Get My Complaints (Student Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/complaints/my-complaints?page=1&limit=10&status=pending" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

### 3. Get All Complaints (Warden Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/complaints?page=1&limit=10&category=maintenance&priority=high" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 4. Update Complaint Status (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/complaints/COMPLAINT_ID/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "status": "resolved",
    "resolution": "WiFi router was replaced and connection is now stable. Issue resolved.",
    "assignedTo": "WARDEN_ID"
  }'
```

### 5. Update Complaint (Student Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/complaints/COMPLAINT_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "subject": "Updated: WiFi not working in my room",
    "description": "The WiFi connection in room 201 has been very poor for the past week. I cannot access online classes properly. This is urgent as I have exams next week.",
    "priority": "urgent"
  }'
```

### 6. Delete Complaint (Student Only)

**cURL:**
```bash
curl -X DELETE http://localhost:3000/api/complaints/COMPLAINT_ID \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

---

## 💰 Fine Management Examples

### 1. Create Fine (Warden Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/fines \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "studentId": "STUDENT_ID",
    "reason": "Late return from gate pass - returned 3 hours after expected time",
    "amount": 750,
    "fineType": "late_return"
  }'
```

### 2. Get My Fines (Student Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/fines/my-fines?page=1&limit=10&status=pending" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

### 3. Get All Fines (Warden Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/fines?page=1&limit=10&status=pending&fineType=late_return" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 4. Update Fine Status (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/fines/FINE_ID/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "status": "paid",
    "amount": 750
  }'
```

### 5. Request Fine Waiver (Student Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/fines/FINE_ID/waiver \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "waiverReason": "I was delayed due to a medical emergency. I have attached the medical certificate as proof."
  }'
```

### 6. Bulk Create Fines (Warden Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/fines/bulk \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "fines": [
      {
        "studentId": "STUDENT_ID_1",
        "reason": "Late return from gate pass",
        "amount": 500,
        "fineType": "late_return"
      },
      {
        "studentId": "STUDENT_ID_2",
        "reason": "Room damage - broken furniture",
        "amount": 1500,
        "fineType": "damage"
      }
    ]
  }'
```

---

## 💳 Payment Examples

### 1. Create Payment Request (Student Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/payments \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "amount": 5000,
    "paymentType": "rent",
    "description": "Rent for January 2024",
    "fineId": null
  }'
```

### 2. Create Rent Payment Request (Student Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/payments/rent \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "month": "January",
    "year": "2024"
  }'
```

### 3. Create Fine Payment Request (Student Only)

**cURL:**
```bash
curl -X POST http://localhost:3000/api/payments \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN" \
  -d '{
    "amount": 750,
    "paymentType": "fine",
    "description": "Payment for late return fine",
    "fineId": "FINE_ID"
  }'
```

### 4. Get My Payments (Student Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/payments/my-payments?page=1&limit=10&status=pending" \
  -H "Authorization: Bearer STUDENT_JWT_TOKEN"
```

### 5. Get All Payments (Warden Only)

**cURL:**
```bash
curl -X GET "http://localhost:3000/api/payments?page=1&limit=10&status=pending&paymentType=rent" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

### 6. Process Payment (Warden Only)

**cURL:**
```bash
curl -X PUT http://localhost:3000/api/payments/PAYMENT_ID/process \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN" \
  -d '{
    "status": "approved",
    "receiptNumber": "RCP-2024-001"
  }'
```

### 7. Generate Receipt (Warden Only)

**cURL:**
```bash
curl -X GET http://localhost:3000/api/payments/PAYMENT_ID/receipt \
  -H "Authorization: Bearer WARDEN_JWT_TOKEN"
```

---

## 📮 Postman Collection

Here's a Postman collection JSON that you can import:

```json
{
  "info": {
    "name": "Hostel Management System API",
    "description": "Complete API collection for Hostel Management System",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "variable": [
    {
      "key": "baseUrl",
      "value": "http://localhost:3000/api",
      "type": "string"
    },
    {
      "key": "studentToken",
      "value": "",
      "type": "string"
    },
    {
      "key": "wardenToken",
      "value": "",
      "type": "string"
    }
  ],
  "item": [
    {
      "name": "Authentication",
      "item": [
        {
          "name": "Register Student",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"username\": \"test_student\",\n  \"email\": \"test.student@university.edu\",\n  \"password\": \"TestPass123\",\n  \"role\": \"student\",\n  \"firstName\": \"Test\",\n  \"lastName\": \"Student\",\n  \"studentId\": \"STU999\",\n  \"course\": \"Computer Science\",\n  \"year\": 1,\n  \"phone\": \"+1234567890\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/auth/register/student",
              "host": ["{{baseUrl}}"],
              "path": ["auth", "register", "student"]
            }
          }
        },
        {
          "name": "Register Warden",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"username\": \"test_warden\",\n  \"email\": \"test.warden@hostel.com\",\n  \"password\": \"TestWarden123\",\n  \"role\": \"warden\",\n  \"firstName\": \"Test\",\n  \"lastName\": \"Warden\",\n  \"employeeId\": \"EMP999\",\n  \"department\": \"Administration\",\n  \"phone\": \"+1234567891\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/auth/register/warden",
              "host": ["{{baseUrl}}"],
              "path": ["auth", "register", "warden"]
            }
          }
        },
        {
          "name": "Login Student",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"email\": \"alice.student@university.edu\",\n  \"password\": \"student123\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/auth/login",
              "host": ["{{baseUrl}}"],
              "path": ["auth", "login"]
            }
          },
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "if (pm.response.code === 200) {",
                  "    const response = pm.response.json();",
                  "    if (response.success && response.data.token) {",
                  "        pm.collectionVariables.set('studentToken', response.data.token);",
                  "    }",
                  "}"
                ]
              }
            }
          ]
        },
        {
          "name": "Login Warden",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"email\": \"admin@hostel.com\",\n  \"password\": \"admin123\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/auth/login",
              "host": ["{{baseUrl}}"],
              "path": ["auth", "login"]
            }
          },
          "event": [
            {
              "listen": "test",
              "script": {
                "exec": [
                  "if (pm.response.code === 200) {",
                  "    const response = pm.response.json();",
                  "    if (response.success && response.data.token) {",
                  "        pm.collectionVariables.set('wardenToken', response.data.token);",
                  "    }",
                  "}"
                ]
              }
            }
          ]
        },
        {
          "name": "Get Profile",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/auth/profile",
              "host": ["{{baseUrl}}"],
              "path": ["auth", "profile"]
            }
          }
        }
      ]
    },
    {
      "name": "Students",
      "item": [
        {
          "name": "Get All Students",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{wardenToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/students?page=1&limit=10",
              "host": ["{{baseUrl}}"],
              "path": ["students"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        },
        {
          "name": "Get My Profile",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/students/my-profile",
              "host": ["{{baseUrl}}"],
              "path": ["students", "my-profile"]
            }
          }
        }
      ]
    },
    {
      "name": "Rooms",
      "item": [
        {
          "name": "Get All Rooms",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/rooms?page=1&limit=10&available=true",
              "host": ["{{baseUrl}}"],
              "path": ["rooms"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                },
                {
                  "key": "available",
                  "value": "true"
                }
              ]
            }
          }
        },
        {
          "name": "Create Room",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              },
              {
                "key": "Authorization",
                "value": "Bearer {{wardenToken}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"roomNumber\": \"106\",\n  \"building\": \"Block B\",\n  \"capacity\": 2,\n  \"floor\": 1,\n  \"roomType\": \"double\",\n  \"rent\": 5000,\n  \"amenities\": [\"WiFi\", \"Air Conditioning\"]\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/rooms",
              "host": ["{{baseUrl}}"],
              "path": ["rooms"]
            }
          }
        }
      ]
    },
    {
      "name": "Gate Passes",
      "item": [
        {
          "name": "Create Gate Pass",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              },
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"reason\": \"Going home for weekend\",\n  \"destination\": \"Home\",\n  \"departureTime\": \"2024-01-20T10:00:00Z\",\n  \"expectedReturnTime\": \"2024-01-22T18:00:00Z\",\n  \"emergencyContact\": \"+1234567890\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/gatepasses",
              "host": ["{{baseUrl}}"],
              "path": ["gatepasses"]
            }
          }
        },
        {
          "name": "Get My Gate Passes",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/gatepasses/my-passes?page=1&limit=10",
              "host": ["{{baseUrl}}"],
              "path": ["gatepasses", "my-passes"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        },
        {
          "name": "Get All Gate Passes",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{wardenToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/gatepasses?page=1&limit=10&status=pending",
              "host": ["{{baseUrl}}"],
              "path": ["gatepasses"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                },
                {
                  "key": "status",
                  "value": "pending"
                }
              ]
            }
          }
        },
        {
          "name": "Approve Gate Pass",
          "request": {
            "method": "PUT",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{wardenToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/gatepasses/:id/approve",
              "host": ["{{baseUrl}}"],
              "path": ["gatepasses", ":id", "approve"]
            }
          }
        }
      ]
    },
    {
      "name": "Complaints",
      "item": [
        {
          "name": "Create Complaint",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              },
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"subject\": \"WiFi not working\",\n  \"description\": \"The WiFi connection in my room has been very poor for the past week. I cannot access online classes properly.\",\n  \"category\": \"maintenance\",\n  \"priority\": \"high\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/complaints",
              "host": ["{{baseUrl}}"],
              "path": ["complaints"]
            }
          }
        },
        {
          "name": "Get My Complaints",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/complaints/my-complaints?page=1&limit=10",
              "host": ["{{baseUrl}}"],
              "path": ["complaints", "my-complaints"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "Fines",
      "item": [
        {
          "name": "Create Fine",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              },
              {
                "key": "Authorization",
                "value": "Bearer {{wardenToken}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"studentId\": \"STUDENT_ID\",\n  \"reason\": \"Late return from gate pass\",\n  \"amount\": 500,\n  \"fineType\": \"late_return\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/fines",
              "host": ["{{baseUrl}}"],
              "path": ["fines"]
            }
          }
        },
        {
          "name": "Get My Fines",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/fines/my-fines?page=1&limit=10",
              "host": ["{{baseUrl}}"],
              "path": ["fines", "my-fines"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        }
      ]
    },
    {
      "name": "Payments",
      "item": [
        {
          "name": "Create Payment Request",
          "request": {
            "method": "POST",
            "header": [
              {
                "key": "Content-Type",
                "value": "application/json"
              },
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "body": {
              "mode": "raw",
              "raw": "{\n  \"amount\": 5000,\n  \"paymentType\": \"rent\",\n  \"description\": \"Rent for January 2024\"\n}"
            },
            "url": {
              "raw": "{{baseUrl}}/payments",
              "host": ["{{baseUrl}}"],
              "path": ["payments"]
            }
          }
        },
        {
          "name": "Get My Payments",
          "request": {
            "method": "GET",
            "header": [
              {
                "key": "Authorization",
                "value": "Bearer {{studentToken}}"
              }
            ],
            "url": {
              "raw": "{{baseUrl}}/payments/my-payments?page=1&limit=10",
              "host": ["{{baseUrl}}"],
              "path": ["payments", "my-payments"],
              "query": [
                {
                  "key": "page",
                  "value": "1"
                },
                {
                  "key": "limit",
                  "value": "10"
                }
              ]
            }
          }
        }
      ]
    }
  ]
}
```

## 🔧 Environment Variables

Create a `.env` file in your project root:

```env
PORT=3000
NODE_ENV=development
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
JWT_EXPIRES_IN=24h
DB_PATH=./db.json
CORS_ORIGIN=*
```

## 🚀 Quick Test Script

Save this as `test-api.sh` and make it executable:

```bash
#!/bin/bash

BASE_URL="http://localhost:3000/api"

echo "🚀 Testing Hostel Management System API..."

# Test health endpoint
echo "1. Testing health endpoint..."
curl -s "$BASE_URL/../health" | jq .

# Register a test student
echo "2. Registering test student..."
STUDENT_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/register/student" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "test_user",
    "email": "test.user@university.edu",
    "password": "TestPass123",
    "role": "student",
    "firstName": "Test",
    "lastName": "User",
    "studentId": "STU999",
    "course": "Computer Science",
    "year": 1,
    "phone": "+1234567890"
  }')

echo $STUDENT_RESPONSE | jq .

# Login as student
echo "3. Logging in as student..."
LOGIN_RESPONSE=$(curl -s -X POST "$BASE_URL/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice.student@university.edu",
    "password": "student123"
  }')

TOKEN=$(echo $LOGIN_RESPONSE | jq -r '.data.token')
echo "Token: $TOKEN"

# Test authenticated endpoint
echo "4. Testing authenticated endpoint..."
curl -s -X GET "$BASE_URL/auth/profile" \
  -H "Authorization: Bearer $TOKEN" | jq .

echo "✅ API testing completed!"
```

Make it executable and run:
```bash
chmod +x test-api.sh
./test-api.sh
```

---

This comprehensive API documentation should help you test and integrate with the Hostel Management System backend! 🎉
