# Hostel Management System Backend

A complete Node.js backend for a Hostel Management System with two roles: **warden** and **student**. Built with Express.js, JWT authentication, bcrypt password hashing, and a JSON-file database using lowdb.

## 🚀 Features

### Authentication & Authorization
- User registration and login for both students and wardens
- JWT-based authentication with role-based access control
- Password hashing using bcrypt
- Secure middleware for protecting routes

### Student Features
- Apply for gate passes
- File complaints
- View and pay fines
- Request room assignments
- Make payment requests (rent, fines, etc.)

### Warden Features
- Approve/reject gate passes
- Manage room assignments
- Raise and manage fines
- Resolve complaints
- Process payment requests
- Generate payment receipts
- Access comprehensive dashboards and statistics

### System Features
- Complete CRUD operations for all entities
- Input validation and sanitization
- Centralized error handling
- Consistent API response format
- Comprehensive logging
- Sample seed data

## 🛠️ Tech Stack

- **Runtime**: Node.js (v14+)
- **Framework**: Express.js
- **Authentication**: JWT (jsonwebtoken)
- **Password Hashing**: bcryptjs
- **Database**: JSON file with lowdb
- **Validation**: express-validator
- **Security**: Helmet, CORS
- **Logging**: Morgan

## 📁 Project Structure

```
hostel-backend/
├── package.json                 # Dependencies and scripts
├── config.env                   # Environment variables
├── server.js                    # Main server file
├── db.json                      # JSON database file (auto-generated)
├── README.md                    # Documentation
├── config/
│   └── db.js                    # Database configuration
├── routes/
│   ├── auth.routes.js           # Authentication routes
│   ├── students.routes.js       # Student management routes
│   ├── wardens.routes.js        # Warden management routes
│   ├── rooms.routes.js          # Room management routes
│   ├── gatepass.routes.js       # Gate pass routes
│   ├── complaints.routes.js     # Complaint routes
│   ├── fines.routes.js          # Fine management routes
│   └── payments.routes.js       # Payment routes
├── controllers/
│   ├── auth.controller.js       # Authentication logic
│   ├── students.controller.js   # Student operations
│   ├── wardens.controller.js    # Warden operations
│   ├── rooms.controller.js      # Room operations
│   ├── gatepass.controller.js   # Gate pass operations
│   ├── complaints.controller.js # Complaint operations
│   ├── fines.controller.js      # Fine operations
│   └── payments.controller.js   # Payment operations
├── middlewares/
│   ├── auth.js                  # JWT authentication middleware
│   ├── role.js                  # Role-based authorization
│   └── errorHandler.js          # Error handling middleware
├── utils/
│   └── validators.js            # Input validation rules
└── scripts/
    └── seed.js                  # Database seeding script
```

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd hostel-backend
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp config.env .env
   ```
   Edit the `.env` file with your configuration:
   ```env
   PORT=3000
   NODE_ENV=development
   JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
   JWT_EXPIRES_IN=24h
   DB_PATH=./db.json
   CORS_ORIGIN=*
   ```

4. **Seed the database with sample data**
   ```bash
   npm run seed
   ```

5. **Start the server**
   ```bash
   # Development mode with auto-reload
   npm run dev
   
   # Production mode
   npm start
   ```

The server will start on `http://localhost:3000`

## 📊 Default Login Credentials

After seeding the database, you can use these credentials:

### Wardens
- **Admin**: `admin@hostel.com` / `admin123`
- **John**: `john.warden@hostel.com` / `warden123`
- **Mary**: `mary.warden@hostel.com` / `warden123`

### Students
- **Alice**: `alice.student@university.edu` / `student123`
- **Bob**: `bob.student@university.edu` / `student123`
- **Charlie**: `charlie.student@university.edu` / `student123`
- **Diana**: `diana.student@university.edu` / `student123`
- **Eve**: `eve.student@university.edu` / `student123`

## 🔗 API Endpoints

### Authentication
- `POST /api/auth/register/student` - Register new student
- `POST /api/auth/register/warden` - Register new warden
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get current user profile
- `PUT /api/auth/profile` - Update user profile
- `PUT /api/auth/change-password` - Change password
- `POST /api/auth/logout` - Logout

### Students
- `GET /api/students` - Get all students (warden only)
- `GET /api/students/my-profile` - Get my profile (student only)
- `GET /api/students/:id` - Get student by ID
- `PUT /api/students/:id` - Update student (warden only)
- `DELETE /api/students/:id` - Deactivate student (warden only)
- `GET /api/students/stats` - Get student statistics (warden only)

### Wardens
- `GET /api/wardens` - Get all wardens
- `GET /api/wardens/my-profile` - Get my profile
- `GET /api/wardens/dashboard` - Get dashboard data
- `GET /api/wardens/:id` - Get warden by ID
- `PUT /api/wardens/:id` - Update warden profile
- `GET /api/wardens/stats` - Get warden statistics

### Rooms
- `GET /api/rooms` - Get all rooms
- `GET /api/rooms/stats` - Get room statistics (warden only)
- `GET /api/rooms/:id` - Get room by ID
- `POST /api/rooms` - Create room (warden only)
- `PUT /api/rooms/:id` - Update room (warden only)
- `DELETE /api/rooms/:id` - Delete room (warden only)
- `POST /api/rooms/:roomId/assign` - Assign student to room (warden only)
- `POST /api/rooms/:roomId/remove` - Remove student from room (warden only)

### Gate Passes
- `GET /api/gatepasses` - Get all gate passes (warden only)
- `GET /api/gatepasses/my-passes` - Get my gate passes (student only)
- `GET /api/gatepasses/:id` - Get gate pass by ID
- `POST /api/gatepasses` - Create gate pass (student only)
- `PUT /api/gatepasses/:id/approve` - Approve gate pass (warden only)
- `PUT /api/gatepasses/:id/reject` - Reject gate pass (warden only)
- `PUT /api/gatepasses/:id/return` - Mark as returned (warden only)
- `PUT /api/gatepasses/:id/cancel` - Cancel gate pass (student only)

### Complaints
- `GET /api/complaints` - Get all complaints (warden only)
- `GET /api/complaints/my-complaints` - Get my complaints (student only)
- `GET /api/complaints/:id` - Get complaint by ID
- `POST /api/complaints` - Create complaint (student only)
- `PUT /api/complaints/:id/status` - Update complaint status (warden only)
- `PUT /api/complaints/:id` - Update complaint (student only)
- `DELETE /api/complaints/:id` - Delete complaint (student only)

### Fines
- `GET /api/fines` - Get all fines (warden only)
- `GET /api/fines/my-fines` - Get my fines (student only)
- `GET /api/fines/:id` - Get fine by ID
- `POST /api/fines` - Create fine (warden only)
- `POST /api/fines/bulk` - Create multiple fines (warden only)
- `PUT /api/fines/:id/status` - Update fine status (warden only)
- `PUT /api/fines/:id/waiver` - Request fine waiver (student only)

### Payments
- `GET /api/payments` - Get all payments (warden only)
- `GET /api/payments/my-payments` - Get my payments (student only)
- `GET /api/payments/:id` - Get payment by ID
- `GET /api/payments/:id/receipt` - Generate receipt (warden only)
- `POST /api/payments` - Create payment request (student only)
- `POST /api/payments/rent` - Create rent payment request (student only)
- `PUT /api/payments/:id/process` - Process payment (warden only)

## 📝 API Response Format

All API responses follow a consistent format:

```json
{
  "success": true|false,
  "message": "Description of the operation",
  "data": {}, // Response data or null
  "errors": [] // Array of error messages (empty if success)
}
```

### Error Response Example
```json
{
  "success": false,
  "message": "Validation failed",
  "data": null,
  "errors": [
    "Email is required",
    "Password must be at least 6 characters"
  ]
}
```

## 🔐 Authentication

### JWT Token
Include the JWT token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

### Role-Based Access
- **Warden**: Full access to all endpoints
- **Student**: Limited access to own data and specific operations

## 📊 Database Schema

The system uses a JSON file database with the following collections:

- **users**: User accounts (students and wardens)
- **students**: Student profiles and details
- **wardens**: Warden profiles and details
- **rooms**: Room information and availability
- **gatePasses**: Gate pass requests and approvals
- **complaints**: Student complaints and resolutions
- **fines**: Fines issued to students
- **payments**: Payment requests and receipts

## 🧪 Testing

Run the seed script to populate the database with test data:
```bash
npm run seed
```

## 📚 Example Usage

### 1. Register a new student
```bash
curl -X POST http://localhost:3000/api/auth/register/student \
  -H "Content-Type: application/json" \
  -d '{
    "username": "new_student",
    "email": "new.student@university.edu",
    "password": "password123",
    "firstName": "New",
    "lastName": "Student",
    "studentId": "STU006",
    "course": "Computer Science",
    "year": 1,
    "phone": "+1234567890"
  }'
```

### 2. Login
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "alice.student@university.edu",
    "password": "student123"
  }'
```

### 3. Create a gate pass (with JWT token)
```bash
curl -X POST http://localhost:3000/api/gatepasses \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -d '{
    "reason": "Going home for the weekend",
    "destination": "Home",
    "departureTime": "2024-01-15T10:00:00Z",
    "expectedReturnTime": "2024-01-17T18:00:00Z",
    "emergencyContact": "+1234567890"
  }'
```

## 🚀 Deployment

### Environment Variables for Production
```env
NODE_ENV=production
PORT=3000
JWT_SECRET=your-super-secure-jwt-secret-key
JWT_EXPIRES_IN=24h
DB_PATH=/path/to/production/db.json
CORS_ORIGIN=https://your-frontend-domain.com
```

### Production Considerations
1. Change the JWT secret to a secure random string
2. Set appropriate CORS origins
3. Use a process manager like PM2
4. Set up proper logging
5. Consider using a proper database (PostgreSQL, MongoDB) for production

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support and questions:
1. Check the API documentation above
2. Review the example requests
3. Check the seed data for sample entities
4. Open an issue for bugs or feature requests

## 🔄 Scripts

- `npm start` - Start the production server
- `npm run dev` - Start development server with auto-reload
- `npm run seed` - Populate database with sample data
- `npm test` - Run tests (when implemented)

---

**Happy coding! 🎉**
