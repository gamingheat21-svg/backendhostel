const jwt = require('jsonwebtoken');
const database = require('../config/db');

/**
 * Authentication middleware to verify JWT tokens
 */
const authenticateToken = (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Access token required',
        data: null,
        errors: ['No token provided']
      });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
        return res.status(403).json({
          success: false,
          message: 'Invalid or expired token',
          data: null,
          errors: ['Token verification failed']
        });
      }

      // Get user from database to ensure user still exists
      const user = database.getById('users', decoded.userId);
      if (!user) {
        return res.status(403).json({
          success: false,
          message: 'User not found',
          data: null,
          errors: ['User account may have been deleted']
        });
      }

      // Add user info to request object
      req.user = {
        id: user.id,
        email: user.email,
        role: user.role,
        username: user.username
      };

      next();
    });
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(500).json({
      success: false,
      message: 'Authentication failed',
      data: null,
      errors: ['Internal server error']
    });
  }
};

/**
 * Generate JWT token for user
 */
const generateToken = (user) => {
  const payload = {
    userId: user.id,
    email: user.email,
    role: user.role
  };

  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '24h'
  });
};

/**
 * Verify token and return decoded data
 */
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    throw new Error('Invalid token');
  }
};

module.exports = {
  authenticateToken,
  generateToken,
  verifyToken
};
