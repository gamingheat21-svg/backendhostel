const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { generateToken } = require('../middlewares/auth');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Register a new user (student or warden)
 */
const register = catchAsync(async (req, res, next) => {
  const { username, email, password, role, firstName, lastName, ...additionalData } = req.body;

  // Check if user already exists
  const existingUser = database.findBy('users', { email })[0];
  if (existingUser) {
    throw new AppError('User with this email already exists', 400, ['Email already registered']);
  }

  // Check if username already exists
  const existingUsername = database.findBy('users', { username })[0];
  if (existingUsername) {
    throw new AppError('Username already taken', 400, ['Username already exists']);
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 12);

  // Create user object
  const userId = uuidv4();
  const user = {
    id: userId,
    username,
    email,
    password: hashedPassword,
    role,
    firstName,
    lastName,
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  // Save user to database
  database.create('users', user);

  // Create role-specific profile
  if (role === 'student') {
    const { studentId, course, year, phone } = additionalData;
    
    // Check if student ID already exists
    const existingStudent = database.findBy('students', { studentId })[0];
    if (existingStudent) {
      // Rollback user creation
      database.delete('users', userId);
      throw new AppError('Student ID already exists', 400, ['Student ID already registered']);
    }

    const student = {
      id: uuidv4(),
      userId,
      studentId,
      course,
      year,
      phone: phone || null,
      roomId: null,
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.create('students', student);
  } else if (role === 'warden') {
    const { employeeId, department, phone } = additionalData;
    
    // Check if employee ID already exists
    const existingWarden = database.findBy('wardens', { employeeId })[0];
    if (existingWarden) {
      // Rollback user creation
      database.delete('users', userId);
      throw new AppError('Employee ID already exists', 400, ['Employee ID already registered']);
    }

    const warden = {
      id: uuidv4(),
      userId,
      employeeId,
      department,
      phone,
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    database.create('wardens', warden);
  }

  // Generate JWT token
  const token = generateToken(user);

  // Remove password from response
  const userResponse = { ...user };
  delete userResponse.password;

  res.status(201).json({
    success: true,
    message: `${role} registered successfully`,
    data: {
      user: userResponse,
      token
    },
    errors: []
  });
});

/**
 * Login user
 */
const login = catchAsync(async (req, res, next) => {
  const { email, password } = req.body;

  // Find user by email
  const user = database.findBy('users', { email })[0];
  if (!user) {
    throw new AppError('Invalid email or password', 401, ['Authentication failed']);
  }

  // Check if user is active
  if (!user.isActive) {
    throw new AppError('Account is deactivated', 401, ['Account deactivated']);
  }

  // Check password
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    throw new AppError('Invalid email or password', 401, ['Authentication failed']);
  }

  // Generate JWT token
  const token = generateToken(user);

  // Get role-specific profile
  let profile = null;
  if (user.role === 'student') {
    profile = database.findBy('students', { userId: user.id })[0];
  } else if (user.role === 'warden') {
    profile = database.findBy('wardens', { userId: user.id })[0];
  }

  // Remove password from response
  const userResponse = { ...user };
  delete userResponse.password;

  res.json({
    success: true,
    message: 'Login successful',
    data: {
      user: userResponse,
      profile,
      token
    },
    errors: []
  });
});

/**
 * Get current user profile
 */
const getProfile = catchAsync(async (req, res, next) => {
  const userId = req.user.id;

  // Get user details
  const user = database.getById('users', userId);
  if (!user) {
    throw new AppError('User not found', 404, ['User does not exist']);
  }

  // Get role-specific profile
  let profile = null;
  if (user.role === 'student') {
    profile = database.findBy('students', { userId })[0];
    if (profile) {
      // Get room details if student has a room
      if (profile.roomId) {
        const room = database.getById('rooms', profile.roomId);
        profile.room = room;
      }
    }
  } else if (user.role === 'warden') {
    profile = database.findBy('wardens', { userId })[0];
  }

  // Remove password from response
  const userResponse = { ...user };
  delete userResponse.password;

  res.json({
    success: true,
    message: 'Profile retrieved successfully',
    data: {
      user: userResponse,
      profile
    },
    errors: []
  });
});

/**
 * Update user profile
 */
const updateProfile = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { firstName, lastName, phone } = req.body;

  // Update user basic info
  const userUpdates = {};
  if (firstName) userUpdates.firstName = firstName;
  if (lastName) userUpdates.lastName = lastName;
  userUpdates.updatedAt = new Date().toISOString();

  database.update('users', userId, userUpdates);

  // Update role-specific profile
  const user = database.getById('users', userId);
  if (user.role === 'student') {
    const student = database.findBy('students', { userId })[0];
    if (student && phone) {
      database.update('students', student.id, {
        phone,
        updatedAt: new Date().toISOString()
      });
    }
  } else if (user.role === 'warden') {
    const warden = database.findBy('wardens', { userId })[0];
    if (warden && phone) {
      database.update('wardens', warden.id, {
        phone,
        updatedAt: new Date().toISOString()
      });
    }
  }

  // Get updated profile
  const updatedUser = database.getById('users', userId);
  let profile = null;
  if (updatedUser.role === 'student') {
    profile = database.findBy('students', { userId })[0];
  } else if (updatedUser.role === 'warden') {
    profile = database.findBy('wardens', { userId })[0];
  }

  // Remove password from response
  const userResponse = { ...updatedUser };
  delete userResponse.password;

  res.json({
    success: true,
    message: 'Profile updated successfully',
    data: {
      user: userResponse,
      profile
    },
    errors: []
  });
});

/**
 * Change password
 */
const changePassword = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { currentPassword, newPassword } = req.body;

  // Get user
  const user = database.getById('users', userId);
  if (!user) {
    throw new AppError('User not found', 404, ['User does not exist']);
  }

  // Verify current password
  const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
  if (!isCurrentPasswordValid) {
    throw new AppError('Current password is incorrect', 400, ['Invalid current password']);
  }

  // Hash new password
  const hashedNewPassword = await bcrypt.hash(newPassword, 12);

  // Update password
  database.update('users', userId, {
    password: hashedNewPassword,
    updatedAt: new Date().toISOString()
  });

  res.json({
    success: true,
    message: 'Password changed successfully',
    data: null,
    errors: []
  });
});

/**
 * Logout (client-side token removal)
 */
const logout = catchAsync(async (req, res, next) => {
  res.json({
    success: true,
    message: 'Logout successful',
    data: null,
    errors: []
  });
});

module.exports = {
  register,
  login,
  getProfile,
  updateProfile,
  changePassword,
  logout
};
