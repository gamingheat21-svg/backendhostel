const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all fines (warden only)
 */
const getAllFines = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, status, fineType, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let fines = database.getAll('fines');
  
  // Apply filters
  if (status) {
    fines = fines.filter(f => f.status === status);
  }
  
  if (fineType) {
    fines = fines.filter(f => f.fineType === fineType);
  }
  
  // Apply sorting
  fines.sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedFines = fines.slice(startIndex, endIndex);
  
  // Get student details for each fine
  const finesWithDetails = paginatedFines.map(fine => {
    const student = database.getById('students', fine.studentId);
    const user = student ? database.getById('users', student.userId) : null;
    
    return {
      ...fine,
      student: student ? {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName
        } : null
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Fines retrieved successfully',
    data: {
      fines: finesWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(fines.length / limit),
        totalFines: fines.length,
        hasNext: endIndex < fines.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get fine by ID
 */
const getFineById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const fine = database.getById('fines', id);
  if (!fine) {
    throw new AppError('Fine not found', 404, ['Fine does not exist']);
  }
  
  const student = database.getById('students', fine.studentId);
  const user = student ? database.getById('users', student.userId) : null;
  
  res.json({
    success: true,
    message: 'Fine retrieved successfully',
    data: {
      fine: {
        ...fine,
        student: student ? {
          ...student,
          user: user ? {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
          } : null
        } : null
      }
    },
    errors: []
  });
});

/**
 * Create new fine (warden only)
 */
const createFine = catchAsync(async (req, res, next) => {
  const { studentId, reason, amount, fineType } = req.body;
  const wardenId = req.user.id;
  
  // Validate student exists
  const student = database.getById('students', studentId);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  // Check if student is active
  if (!student.isActive) {
    throw new AppError('Cannot create fine for inactive student', 400, ['Student is inactive']);
  }
  
  const fine = {
    id: uuidv4(),
    studentId,
    reason,
    amount: parseFloat(amount),
    fineType,
    status: 'pending',
    issuedBy: wardenId,
    issuedAt: new Date().toISOString(),
    paidAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('fines', fine);
  
  res.status(201).json({
    success: true,
    message: 'Fine created successfully',
    data: { fine },
    errors: []
  });
});

/**
 * Update fine status (warden only)
 */
const updateFineStatus = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { status, amount } = req.body;
  const wardenId = req.user.id;
  
  const fine = database.getById('fines', id);
  if (!fine) {
    throw new AppError('Fine not found', 404, ['Fine does not exist']);
  }
  
  if (!['pending', 'paid', 'waived', 'cancelled'].includes(status)) {
    throw new AppError('Invalid status', 400, ['Status must be pending, paid, waived, or cancelled']);
  }
  
  const updates = {
    status,
    updatedAt: new Date().toISOString()
  };
  
  if (status === 'paid') {
    updates.paidAt = new Date().toISOString();
  }
  
  if (amount !== undefined) {
    updates.amount = parseFloat(amount);
  }
  
  database.update('fines', id, updates);
  
  const updatedFine = database.getById('fines', id);
  
  res.json({
    success: true,
    message: 'Fine status updated successfully',
    data: { fine: updatedFine },
    errors: []
  });
});

/**
 * Get my fines (student only)
 */
const getMyFines = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { page = 1, limit = 10, status } = req.query;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  let fines = database.findBy('fines', { studentId: student.id });
  
  // Apply status filter
  if (status) {
    fines = fines.filter(f => f.status === status);
  }
  
  // Sort by creation date (newest first)
  fines.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedFines = fines.slice(startIndex, endIndex);
  
  // Calculate total pending amount
  const pendingFines = fines.filter(f => f.status === 'pending');
  const totalPendingAmount = pendingFines.reduce((sum, fine) => sum + fine.amount, 0);
  
  res.json({
    success: true,
    message: 'My fines retrieved successfully',
    data: {
      fines: paginatedFines,
      summary: {
        total: fines.length,
        pending: pendingFines.length,
        paid: fines.filter(f => f.status === 'paid').length,
        totalPendingAmount
      },
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(fines.length / limit),
        totalFines: fines.length,
        hasNext: endIndex < fines.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Request fine waiver (student only)
 */
const requestFineWaiver = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { waiverReason } = req.body;
  const userId = req.user.id;
  
  const fine = database.getById('fines', id);
  if (!fine) {
    throw new AppError('Fine not found', 404, ['Fine does not exist']);
  }
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if fine belongs to the student
  if (fine.studentId !== student.id) {
    throw new AppError('Access denied', 403, ['You can only request waiver for your own fines']);
  }
  
  // Check if fine can be waived
  if (fine.status !== 'pending') {
    throw new AppError('Fine cannot be waived', 400, ['Only pending fines can be waived']);
  }
  
  if (!waiverReason || waiverReason.trim().length < 10) {
    throw new AppError('Waiver reason is required', 400, ['Please provide a valid waiver reason']);
  }
  
  database.update('fines', id, {
    status: 'waiver_requested',
    waiverReason: waiverReason.trim(),
    updatedAt: new Date().toISOString()
  });
  
  const updatedFine = database.getById('fines', id);
  
  res.json({
    success: true,
    message: 'Fine waiver requested successfully',
    data: { fine: updatedFine },
    errors: []
  });
});

/**
 * Get fine statistics (warden only)
 */
const getFineStats = catchAsync(async (req, res, next) => {
  const fines = database.getAll('fines');
  
  const stats = {
    total: fines.length,
    pending: 0,
    paid: 0,
    waived: 0,
    cancelled: 0,
    waiver_requested: 0
  };
  
  const typeStats = {};
  const amountStats = {
    totalAmount: 0,
    pendingAmount: 0,
    paidAmount: 0,
    waivedAmount: 0
  };
  
  fines.forEach(fine => {
    stats[fine.status]++;
    
    // Type stats
    if (!typeStats[fine.fineType]) {
      typeStats[fine.fineType] = 0;
    }
    typeStats[fine.fineType]++;
    
    // Amount stats
    amountStats.totalAmount += fine.amount;
    if (fine.status === 'pending') {
      amountStats.pendingAmount += fine.amount;
    } else if (fine.status === 'paid') {
      amountStats.paidAmount += fine.amount;
    } else if (fine.status === 'waived') {
      amountStats.waivedAmount += fine.amount;
    }
  });
  
  // Get recent fines (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentFines = fines.filter(f => 
    new Date(f.createdAt) >= thirtyDaysAgo
  );
  
  // Get overdue fines (pending for more than 30 days)
  const thirtyDaysAgoForOverdue = new Date();
  thirtyDaysAgoForOverdue.setDate(thirtyDaysAgoForOverdue.getDate() - 30);
  
  const overdueFines = fines.filter(f => 
    f.status === 'pending' && 
    new Date(f.createdAt) <= thirtyDaysAgoForOverdue
  );
  
  res.json({
    success: true,
    message: 'Fine statistics retrieved successfully',
    data: {
      overall: stats,
      byType: typeStats,
      amounts: amountStats,
      recent: recentFines.length,
      overdue: overdueFines.length
    },
    errors: []
  });
});

/**
 * Bulk create fines (warden only)
 */
const bulkCreateFines = catchAsync(async (req, res, next) => {
  const { fines } = req.body;
  const wardenId = req.user.id;
  
  if (!Array.isArray(fines) || fines.length === 0) {
    throw new AppError('Invalid fines data', 400, ['Fines must be a non-empty array']);
  }
  
  const createdFines = [];
  const errors = [];
  
  for (let i = 0; i < fines.length; i++) {
    const fineData = fines[i];
    const { studentId, reason, amount, fineType } = fineData;
    
    try {
      // Validate student exists
      const student = database.getById('students', studentId);
      if (!student) {
        errors.push(`Row ${i + 1}: Student not found`);
        continue;
      }
      
      // Check if student is active
      if (!student.isActive) {
        errors.push(`Row ${i + 1}: Student is inactive`);
        continue;
      }
      
      const fine = {
        id: uuidv4(),
        studentId,
        reason,
        amount: parseFloat(amount),
        fineType,
        status: 'pending',
        issuedBy: wardenId,
        issuedAt: new Date().toISOString(),
        paidAt: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      database.create('fines', fine);
      createdFines.push(fine);
    } catch (error) {
      errors.push(`Row ${i + 1}: ${error.message}`);
    }
  }
  
  res.status(201).json({
    success: true,
    message: `Bulk fine creation completed. ${createdFines.length} fines created, ${errors.length} errors`,
    data: {
      createdFines,
      errors
    },
    errors: errors.length > 0 ? errors : []
  });
});

module.exports = {
  getAllFines,
  getFineById,
  createFine,
  updateFineStatus,
  getMyFines,
  requestFineWaiver,
  getFineStats,
  bulkCreateFines
};
