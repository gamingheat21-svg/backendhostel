const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all students (warden only)
 */
const getAllStudents = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let students = database.getAll('students');
  
  // Apply search filter
  if (search) {
    students = students.filter(student => {
      const user = database.getById('users', student.userId);
      if (!user) return false;
      
      return (
        student.studentId.toLowerCase().includes(search.toLowerCase()) ||
        user.firstName.toLowerCase().includes(search.toLowerCase()) ||
        user.lastName.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase()) ||
        student.course.toLowerCase().includes(search.toLowerCase())
      );
    });
  }
  
  // Apply sorting
  students.sort((a, b) => {
    let aValue, bValue;
    
    if (sortBy === 'name') {
      const userA = database.getById('users', a.userId);
      const userB = database.getById('users', b.userId);
      aValue = userA ? `${userA.firstName} ${userA.lastName}` : '';
      bValue = userB ? `${userB.firstName} ${userB.lastName}` : '';
    } else {
      aValue = a[sortBy] || '';
      bValue = b[sortBy] || '';
    }
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedStudents = students.slice(startIndex, endIndex);
  
  // Get user details for each student
  const studentsWithDetails = paginatedStudents.map(student => {
    const user = database.getById('users', student.userId);
    const room = student.roomId ? database.getById('rooms', student.roomId) : null;
    
    return {
      ...student,
      user: user ? {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isActive: user.isActive,
        createdAt: user.createdAt
      } : null,
      room
    };
  });
  
  res.json({
    success: true,
    message: 'Students retrieved successfully',
    data: {
      students: studentsWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(students.length / limit),
        totalStudents: students.length,
        hasNext: endIndex < students.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get student by ID
 */
const getStudentById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const student = database.getById('students', id);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  const user = database.getById('users', student.userId);
  const room = student.roomId ? database.getById('rooms', student.roomId) : null;
  
  // Get additional student data
  const gatePasses = database.findBy('gatePasses', { studentId: student.id });
  const complaints = database.findBy('complaints', { studentId: student.id });
  const fines = database.findBy('fines', { studentId: student.id });
  const payments = database.findBy('payments', { studentId: student.id });
  
  res.json({
    success: true,
    message: 'Student retrieved successfully',
    data: {
      student: {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null,
        room,
        gatePasses: gatePasses.length,
        complaints: complaints.length,
        fines: fines.length,
        payments: payments.length
      }
    },
    errors: []
  });
});

/**
 * Update student profile (warden only)
 */
const updateStudent = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { course, year, phone, roomId, isActive } = req.body;
  
  const student = database.getById('students', id);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  // Validate room assignment
  if (roomId) {
    const room = database.getById('rooms', roomId);
    if (!room) {
      throw new AppError('Room not found', 400, ['Invalid room ID']);
    }
    
    // Check if room has available capacity
    const currentOccupants = database.findBy('students', { roomId, isActive: true }).length;
    if (currentOccupants >= room.capacity) {
      throw new AppError('Room is at full capacity', 400, ['Room capacity exceeded']);
    }
  }
  
  const updates = {
    updatedAt: new Date().toISOString()
  };
  
  if (course !== undefined) updates.course = course;
  if (year !== undefined) updates.year = year;
  if (phone !== undefined) updates.phone = phone;
  if (roomId !== undefined) updates.roomId = roomId;
  if (isActive !== undefined) updates.isActive = isActive;
  
  database.update('students', id, updates);
  
  // Get updated student
  const updatedStudent = database.getById('students', id);
  const user = database.getById('users', updatedStudent.userId);
  const room = updatedStudent.roomId ? database.getById('rooms', updatedStudent.roomId) : null;
  
  res.json({
    success: true,
    message: 'Student updated successfully',
    data: {
      student: {
        ...updatedStudent,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null,
        room
      }
    },
    errors: []
  });
});

/**
 * Deactivate student (warden only)
 */
const deactivateStudent = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const student = database.getById('students', id);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  database.update('students', id, {
    isActive: false,
    updatedAt: new Date().toISOString()
  });
  
  // Also deactivate user account
  database.update('users', student.userId, {
    isActive: false,
    updatedAt: new Date().toISOString()
  });
  
  res.json({
    success: true,
    message: 'Student deactivated successfully',
    data: null,
    errors: []
  });
});

/**
 * Get student statistics (warden only)
 */
const getStudentStats = catchAsync(async (req, res, next) => {
  const students = database.getAll('students');
  const activeStudents = students.filter(s => s.isActive);
  const inactiveStudents = students.filter(s => !s.isActive);
  
  // Get room occupancy
  const rooms = database.getAll('rooms');
  const roomOccupancy = rooms.map(room => {
    const occupants = database.findBy('students', { roomId: room.id, isActive: true });
    return {
      roomId: room.id,
      roomNumber: room.roomNumber,
      building: room.building,
      capacity: room.capacity,
      occupied: occupants.length,
      available: room.capacity - occupants.length
    };
  });
  
  // Get students by year
  const studentsByYear = {};
  activeStudents.forEach(student => {
    const year = student.year;
    studentsByYear[year] = (studentsByYear[year] || 0) + 1;
  });
  
  // Get students by course
  const studentsByCourse = {};
  activeStudents.forEach(student => {
    const course = student.course;
    studentsByCourse[course] = (studentsByCourse[course] || 0) + 1;
  });
  
  res.json({
    success: true,
    message: 'Student statistics retrieved successfully',
    data: {
      totalStudents: students.length,
      activeStudents: activeStudents.length,
      inactiveStudents: inactiveStudents.length,
      roomOccupancy,
      studentsByYear,
      studentsByCourse
    },
    errors: []
  });
});

/**
 * Get my profile (student only)
 */
const getMyProfile = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  const user = database.getById('users', userId);
  const room = student.roomId ? database.getById('rooms', student.roomId) : null;
  
  // Get recent activities
  const recentGatePasses = database.findBy('gatePasses', { studentId: student.id })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);
  
  const recentComplaints = database.findBy('complaints', { studentId: student.id })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);
  
  const pendingFines = database.findBy('fines', { studentId: student.id, status: 'pending' });
  const totalPendingFines = pendingFines.reduce((sum, fine) => sum + fine.amount, 0);
  
  res.json({
    success: true,
    message: 'Profile retrieved successfully',
    data: {
      student: {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null,
        room
      },
      recentActivities: {
        recentGatePasses,
        recentComplaints,
        pendingFines: pendingFines.length,
        totalPendingAmount: totalPendingFines
      }
    },
    errors: []
  });
});

module.exports = {
  getAllStudents,
  getStudentById,
  updateStudent,
  deactivateStudent,
  getStudentStats,
  getMyProfile
};
