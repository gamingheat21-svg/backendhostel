const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all payments (warden only)
 */
const getAllPayments = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, status, paymentType, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let payments = database.getAll('payments');
  
  // Apply filters
  if (status) {
    payments = payments.filter(p => p.status === status);
  }
  
  if (paymentType) {
    payments = payments.filter(p => p.paymentType === paymentType);
  }
  
  // Apply sorting
  payments.sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedPayments = payments.slice(startIndex, endIndex);
  
  // Get student details for each payment
  const paymentsWithDetails = paginatedPayments.map(payment => {
    const student = database.getById('students', payment.studentId);
    const user = student ? database.getById('users', student.userId) : null;
    
    return {
      ...payment,
      student: student ? {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName
        } : null
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Payments retrieved successfully',
    data: {
      payments: paymentsWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(payments.length / limit),
        totalPayments: payments.length,
        hasNext: endIndex < payments.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get payment by ID
 */
const getPaymentById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const payment = database.getById('payments', id);
  if (!payment) {
    throw new AppError('Payment not found', 404, ['Payment does not exist']);
  }
  
  const student = database.getById('students', payment.studentId);
  const user = student ? database.getById('users', student.userId) : null;
  
  res.json({
    success: true,
    message: 'Payment retrieved successfully',
    data: {
      payment: {
        ...payment,
        student: student ? {
          ...student,
          user: user ? {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
          } : null
        } : null
      }
    },
    errors: []
  });
});

/**
 * Create new payment request (student only)
 */
const createPaymentRequest = catchAsync(async (req, res, next) => {
  const { amount, paymentType, description, fineId } = req.body;
  const userId = req.user.id;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // If this is a fine payment, validate the fine
  if (fineId) {
    const fine = database.getById('fines', fineId);
    if (!fine) {
      throw new AppError('Fine not found', 404, ['Fine does not exist']);
    }
    
    // Check if fine belongs to the student
    if (fine.studentId !== student.id) {
      throw new AppError('Access denied', 403, ['You can only pay for your own fines']);
    }
    
    // Check if fine is pending
    if (fine.status !== 'pending') {
      throw new AppError('Fine is not pending', 400, ['Fine has already been processed']);
    }
  }
  
  const payment = {
    id: uuidv4(),
    studentId: student.id,
    amount: parseFloat(amount),
    paymentType,
    description: description || null,
    fineId: fineId || null,
    status: 'pending',
    receiptNumber: null,
    processedBy: null,
    processedAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('payments', payment);
  
  res.status(201).json({
    success: true,
    message: 'Payment request created successfully',
    data: { payment },
    errors: []
  });
});

/**
 * Process payment (warden only)
 */
const processPayment = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { status, receiptNumber } = req.body;
  const wardenId = req.user.id;
  
  const payment = database.getById('payments', id);
  if (!payment) {
    throw new AppError('Payment not found', 404, ['Payment does not exist']);
  }
  
  if (payment.status !== 'pending') {
    throw new AppError('Payment is not pending', 400, ['Payment has already been processed']);
  }
  
  if (!['approved', 'rejected'].includes(status)) {
    throw new AppError('Invalid status', 400, ['Status must be approved or rejected']);
  }
  
  const updates = {
    status,
    processedBy: wardenId,
    processedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  if (status === 'approved') {
    // Generate receipt number if not provided
    updates.receiptNumber = receiptNumber || `RCP-${Date.now()}`;
    
    // If this is a fine payment, update the fine status
    if (payment.fineId) {
      database.update('fines', payment.fineId, {
        status: 'paid',
        paidAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
    }
  }
  
  database.update('payments', id, updates);
  
  const updatedPayment = database.getById('payments', id);
  
  res.json({
    success: true,
    message: `Payment ${status} successfully`,
    data: { payment: updatedPayment },
    errors: []
  });
});

/**
 * Get my payments (student only)
 */
const getMyPayments = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { page = 1, limit = 10, status } = req.query;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  let payments = database.findBy('payments', { studentId: student.id });
  
  // Apply status filter
  if (status) {
    payments = payments.filter(p => p.status === status);
  }
  
  // Sort by creation date (newest first)
  payments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedPayments = payments.slice(startIndex, endIndex);
  
  // Calculate summary
  const pendingPayments = payments.filter(p => p.status === 'pending');
  const approvedPayments = payments.filter(p => p.status === 'approved');
  const totalPendingAmount = pendingPayments.reduce((sum, payment) => sum + payment.amount, 0);
  const totalApprovedAmount = approvedPayments.reduce((sum, payment) => sum + payment.amount, 0);
  
  res.json({
    success: true,
    message: 'My payments retrieved successfully',
    data: {
      payments: paginatedPayments,
      summary: {
        total: payments.length,
        pending: pendingPayments.length,
        approved: approvedPayments.length,
        rejected: payments.filter(p => p.status === 'rejected').length,
        totalPendingAmount,
        totalApprovedAmount
      },
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(payments.length / limit),
        totalPayments: payments.length,
        hasNext: endIndex < payments.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Generate payment receipt (warden only)
 */
const generateReceipt = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const payment = database.getById('payments', id);
  if (!payment) {
    throw new AppError('Payment not found', 404, ['Payment does not exist']);
  }
  
  if (payment.status !== 'approved') {
    throw new AppError('Payment is not approved', 400, ['Only approved payments can generate receipts']);
  }
  
  const student = database.getById('students', payment.studentId);
  const user = student ? database.getById('users', student.userId) : null;
  
  // Generate receipt data
  const receipt = {
    receiptNumber: payment.receiptNumber,
    paymentId: payment.id,
    student: {
      name: user ? `${user.firstName} ${user.lastName}` : 'N/A',
      email: user ? user.email : 'N/A',
      studentId: student ? student.studentId : 'N/A'
    },
    payment: {
      amount: payment.amount,
      type: payment.paymentType,
      description: payment.description,
      processedAt: payment.processedAt,
      receiptNumber: payment.receiptNumber
    },
    generatedAt: new Date().toISOString()
  };
  
  res.json({
    success: true,
    message: 'Receipt generated successfully',
    data: { receipt },
    errors: []
  });
});

/**
 * Get payment statistics (warden only)
 */
const getPaymentStats = catchAsync(async (req, res, next) => {
  const payments = database.getAll('payments');
  
  const stats = {
    total: payments.length,
    pending: 0,
    approved: 0,
    rejected: 0
  };
  
  const typeStats = {};
  const amountStats = {
    totalAmount: 0,
    pendingAmount: 0,
    approvedAmount: 0,
    rejectedAmount: 0
  };
  
  payments.forEach(payment => {
    stats[payment.status]++;
    
    // Type stats
    if (!typeStats[payment.paymentType]) {
      typeStats[payment.paymentType] = 0;
    }
    typeStats[payment.paymentType]++;
    
    // Amount stats
    amountStats.totalAmount += payment.amount;
    if (payment.status === 'pending') {
      amountStats.pendingAmount += payment.amount;
    } else if (payment.status === 'approved') {
      amountStats.approvedAmount += payment.amount;
    } else if (payment.status === 'rejected') {
      amountStats.rejectedAmount += payment.amount;
    }
  });
  
  // Get recent payments (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentPayments = payments.filter(p => 
    new Date(p.createdAt) >= thirtyDaysAgo
  );
  
  // Get monthly revenue (last 12 months)
  const monthlyRevenue = {};
  const twelveMonthsAgo = new Date();
  twelveMonthsAgo.setMonth(twelveMonthsAgo.getMonth() - 12);
  
  payments
    .filter(p => p.status === 'approved' && new Date(p.processedAt) >= twelveMonthsAgo)
    .forEach(payment => {
      const month = new Date(payment.processedAt).toISOString().substring(0, 7); // YYYY-MM
      monthlyRevenue[month] = (monthlyRevenue[month] || 0) + payment.amount;
    });
  
  res.json({
    success: true,
    message: 'Payment statistics retrieved successfully',
    data: {
      overall: stats,
      byType: typeStats,
      amounts: amountStats,
      recent: recentPayments.length,
      monthlyRevenue
    },
    errors: []
  });
});

/**
 * Create rent payment request (student only)
 */
const createRentPaymentRequest = catchAsync(async (req, res, next) => {
  const { month, year } = req.body;
  const userId = req.user.id;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if student has a room
  if (!student.roomId) {
    throw new AppError('No room assigned', 400, ['Student is not assigned to any room']);
  }
  
  const room = database.getById('rooms', student.roomId);
  if (!room) {
    throw new AppError('Room not found', 404, ['Assigned room does not exist']);
  }
  
  // Check if rent payment already exists for this month/year
  const existingPayment = database.findBy('payments', { 
    studentId: student.id, 
    paymentType: 'rent',
    description: `Rent for ${month}/${year}`,
    status: { $in: ['pending', 'approved'] }
  })[0];
  
  if (existingPayment) {
    throw new AppError('Rent payment already exists', 400, ['Rent payment for this month already exists']);
  }
  
  const payment = {
    id: uuidv4(),
    studentId: student.id,
    amount: room.rent,
    paymentType: 'rent',
    description: `Rent for ${month}/${year}`,
    fineId: null,
    status: 'pending',
    receiptNumber: null,
    processedBy: null,
    processedAt: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('payments', payment);
  
  res.status(201).json({
    success: true,
    message: 'Rent payment request created successfully',
    data: { payment },
    errors: []
  });
});

module.exports = {
  getAllPayments,
  getPaymentById,
  createPaymentRequest,
  processPayment,
  getMyPayments,
  generateReceipt,
  getPaymentStats,
  createRentPaymentRequest
};
