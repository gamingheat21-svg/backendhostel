const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all gate passes (warden only)
 */
const getAllGatePasses = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, status, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let gatePasses = database.getAll('gatePasses');
  
  // Apply status filter
  if (status) {
    gatePasses = gatePasses.filter(gp => gp.status === status);
  }
  
  // Apply sorting
  gatePasses.sort((a, b) => {
    const aValue = a[sortBy];
    const bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedGatePasses = gatePasses.slice(startIndex, endIndex);
  
  // Get student details for each gate pass
  const gatePassesWithDetails = paginatedGatePasses.map(gatePass => {
    const student = database.getById('students', gatePass.studentId);
    const user = student ? database.getById('users', student.userId) : null;
    
    return {
      ...gatePass,
      student: student ? {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName
        } : null
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Gate passes retrieved successfully',
    data: {
      gatePasses: gatePassesWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(gatePasses.length / limit),
        totalGatePasses: gatePasses.length,
        hasNext: endIndex < gatePasses.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get gate pass by ID
 */
const getGatePassById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const gatePass = database.getById('gatePasses', id);
  if (!gatePass) {
    throw new AppError('Gate pass not found', 404, ['Gate pass does not exist']);
  }
  
  const student = database.getById('students', gatePass.studentId);
  const user = student ? database.getById('users', student.userId) : null;
  
  res.json({
    success: true,
    message: 'Gate pass retrieved successfully',
    data: {
      gatePass: {
        ...gatePass,
        student: student ? {
          ...student,
          user: user ? {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
          } : null
        } : null
      }
    },
    errors: []
  });
});

/**
 * Create new gate pass (student only)
 */
const createGatePass = catchAsync(async (req, res, next) => {
  const { reason, destination, departureTime, expectedReturnTime, emergencyContact } = req.body;
  const userId = req.user.id;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if student has any pending gate passes
  const pendingGatePasses = database.findBy('gatePasses', { 
    studentId: student.id, 
    status: 'pending' 
  });
  
  if (pendingGatePasses.length > 0) {
    throw new AppError('You already have a pending gate pass', 400, ['Cannot create multiple pending gate passes']);
  }
  
  // Validate departure time is not in the past
  const departureDate = new Date(departureTime);
  const now = new Date();
  if (departureDate <= now) {
    throw new AppError('Departure time must be in the future', 400, ['Invalid departure time']);
  }
  
  // Validate expected return time is after departure time
  const returnDate = new Date(expectedReturnTime);
  if (returnDate <= departureDate) {
    throw new AppError('Expected return time must be after departure time', 400, ['Invalid return time']);
  }
  
  const gatePass = {
    id: uuidv4(),
    studentId: student.id,
    reason,
    destination,
    departureTime,
    expectedReturnTime,
    emergencyContact: emergencyContact || null,
    status: 'pending',
    approvedBy: null,
    approvedAt: null,
    rejectionReason: null,
    actualReturnTime: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('gatePasses', gatePass);
  
  res.status(201).json({
    success: true,
    message: 'Gate pass created successfully',
    data: { gatePass },
    errors: []
  });
});

/**
 * Approve gate pass (warden only)
 */
const approveGatePass = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const wardenId = req.user.id;
  
  const gatePass = database.getById('gatePasses', id);
  if (!gatePass) {
    throw new AppError('Gate pass not found', 404, ['Gate pass does not exist']);
  }
  
  if (gatePass.status !== 'pending') {
    throw new AppError('Gate pass is not pending', 400, ['Gate pass has already been processed']);
  }
  
  database.update('gatePasses', id, {
    status: 'approved',
    approvedBy: wardenId,
    approvedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
  
  const updatedGatePass = database.getById('gatePasses', id);
  
  res.json({
    success: true,
    message: 'Gate pass approved successfully',
    data: { gatePass: updatedGatePass },
    errors: []
  });
});

/**
 * Reject gate pass (warden only)
 */
const rejectGatePass = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { rejectionReason } = req.body;
  const wardenId = req.user.id;
  
  const gatePass = database.getById('gatePasses', id);
  if (!gatePass) {
    throw new AppError('Gate pass not found', 404, ['Gate pass does not exist']);
  }
  
  if (gatePass.status !== 'pending') {
    throw new AppError('Gate pass is not pending', 400, ['Gate pass has already been processed']);
  }
  
  if (!rejectionReason || rejectionReason.trim().length < 5) {
    throw new AppError('Rejection reason is required', 400, ['Please provide a valid rejection reason']);
  }
  
  database.update('gatePasses', id, {
    status: 'rejected',
    approvedBy: wardenId,
    approvedAt: new Date().toISOString(),
    rejectionReason: rejectionReason.trim(),
    updatedAt: new Date().toISOString()
  });
  
  const updatedGatePass = database.getById('gatePasses', id);
  
  res.json({
    success: true,
    message: 'Gate pass rejected successfully',
    data: { gatePass: updatedGatePass },
    errors: []
  });
});

/**
 * Mark gate pass as returned (warden only)
 */
const markGatePassReturned = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { actualReturnTime } = req.body;
  
  const gatePass = database.getById('gatePasses', id);
  if (!gatePass) {
    throw new AppError('Gate pass not found', 404, ['Gate pass does not exist']);
  }
  
  if (gatePass.status !== 'approved') {
    throw new AppError('Gate pass is not approved', 400, ['Only approved gate passes can be marked as returned']);
  }
  
  const returnTime = actualReturnTime ? new Date(actualReturnTime) : new Date();
  
  database.update('gatePasses', id, {
    status: 'returned',
    actualReturnTime: returnTime.toISOString(),
    updatedAt: new Date().toISOString()
  });
  
  const updatedGatePass = database.getById('gatePasses', id);
  
  res.json({
    success: true,
    message: 'Gate pass marked as returned successfully',
    data: { gatePass: updatedGatePass },
    errors: []
  });
});

/**
 * Get my gate passes (student only)
 */
const getMyGatePasses = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { page = 1, limit = 10, status } = req.query;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  let gatePasses = database.findBy('gatePasses', { studentId: student.id });
  
  // Apply status filter
  if (status) {
    gatePasses = gatePasses.filter(gp => gp.status === status);
  }
  
  // Sort by creation date (newest first)
  gatePasses.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedGatePasses = gatePasses.slice(startIndex, endIndex);
  
  res.json({
    success: true,
    message: 'My gate passes retrieved successfully',
    data: {
      gatePasses: paginatedGatePasses,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(gatePasses.length / limit),
        totalGatePasses: gatePasses.length,
        hasNext: endIndex < gatePasses.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Cancel gate pass (student only)
 */
const cancelGatePass = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const userId = req.user.id;
  
  const gatePass = database.getById('gatePasses', id);
  if (!gatePass) {
    throw new AppError('Gate pass not found', 404, ['Gate pass does not exist']);
  }
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if gate pass belongs to the student
  if (gatePass.studentId !== student.id) {
    throw new AppError('Access denied', 403, ['You can only cancel your own gate passes']);
  }
  
  // Check if gate pass can be cancelled
  if (gatePass.status !== 'pending') {
    throw new AppError('Gate pass cannot be cancelled', 400, ['Only pending gate passes can be cancelled']);
  }
  
  database.update('gatePasses', id, {
    status: 'cancelled',
    updatedAt: new Date().toISOString()
  });
  
  const updatedGatePass = database.getById('gatePasses', id);
  
  res.json({
    success: true,
    message: 'Gate pass cancelled successfully',
    data: { gatePass: updatedGatePass },
    errors: []
  });
});

/**
 * Get gate pass statistics (warden only)
 */
const getGatePassStats = catchAsync(async (req, res, next) => {
  const gatePasses = database.getAll('gatePasses');
  
  const stats = {
    total: gatePasses.length,
    pending: 0,
    approved: 0,
    rejected: 0,
    returned: 0,
    cancelled: 0
  };
  
  gatePasses.forEach(gp => {
    stats[gp.status]++;
  });
  
  // Get recent gate passes (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentGatePasses = gatePasses.filter(gp => 
    new Date(gp.createdAt) >= thirtyDaysAgo
  );
  
  // Get pending gate passes that are overdue
  const now = new Date();
  const overdueGatePasses = gatePasses.filter(gp => 
    gp.status === 'approved' && 
    new Date(gp.expectedReturnTime) < now
  );
  
  res.json({
    success: true,
    message: 'Gate pass statistics retrieved successfully',
    data: {
      overall: stats,
      recent: recentGatePasses.length,
      overdue: overdueGatePasses.length
    },
    errors: []
  });
});

module.exports = {
  getAllGatePasses,
  getGatePassById,
  createGatePass,
  approveGatePass,
  rejectGatePass,
  markGatePassReturned,
  getMyGatePasses,
  cancelGatePass,
  getGatePassStats
};
