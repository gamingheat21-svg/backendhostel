const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all rooms
 */
const getAllRooms = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, search, building, roomType, available, sortBy = 'roomNumber', sortOrder = 'asc' } = req.query;
  
  let rooms = database.getAll('rooms');
  
  // Apply filters
  if (search) {
    rooms = rooms.filter(room => 
      room.roomNumber.toLowerCase().includes(search.toLowerCase()) ||
      room.building.toLowerCase().includes(search.toLowerCase())
    );
  }
  
  if (building) {
    rooms = rooms.filter(room => 
      room.building.toLowerCase() === building.toLowerCase()
    );
  }
  
  if (roomType) {
    rooms = rooms.filter(room => room.roomType === roomType);
  }
  
  // Apply sorting
  rooms.sort((a, b) => {
    let aValue = a[sortBy];
    let bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Get room occupancy
  const roomsWithOccupancy = rooms.map(room => {
    const occupants = database.findBy('students', { roomId: room.id, isActive: true });
    return {
      ...room,
      occupants: occupants.length,
      available: room.capacity - occupants.length,
      isAvailable: room.capacity > occupants.length
    };
  });
  
  // Filter by availability if requested
  let filteredRooms = roomsWithOccupancy;
  if (available === 'true') {
    filteredRooms = roomsWithOccupancy.filter(room => room.isAvailable);
  } else if (available === 'false') {
    filteredRooms = roomsWithOccupancy.filter(room => !room.isAvailable);
  }
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedRooms = filteredRooms.slice(startIndex, endIndex);
  
  res.json({
    success: true,
    message: 'Rooms retrieved successfully',
    data: {
      rooms: paginatedRooms,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(filteredRooms.length / limit),
        totalRooms: filteredRooms.length,
        hasNext: endIndex < filteredRooms.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get room by ID
 */
const getRoomById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const room = database.getById('rooms', id);
  if (!room) {
    throw new AppError('Room not found', 404, ['Room does not exist']);
  }
  
  // Get occupants
  const occupants = database.findBy('students', { roomId: id, isActive: true });
  const occupantsWithDetails = occupants.map(occupant => {
    const user = database.getById('users', occupant.userId);
    return {
      ...occupant,
      user: user ? {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Room retrieved successfully',
    data: {
      room: {
        ...room,
        occupants: occupantsWithDetails,
        occupancy: occupants.length,
        available: room.capacity - occupants.length
      }
    },
    errors: []
  });
});

/**
 * Create new room (warden only)
 */
const createRoom = catchAsync(async (req, res, next) => {
  const { roomNumber, building, capacity, floor, roomType, rent, amenities } = req.body;
  
  // Check if room already exists
  const existingRoom = database.findBy('rooms', { roomNumber, building })[0];
  if (existingRoom) {
    throw new AppError('Room already exists', 400, ['Room with this number already exists in this building']);
  }
  
  const room = {
    id: uuidv4(),
    roomNumber,
    building,
    capacity,
    floor,
    roomType,
    rent,
    amenities: amenities || [],
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('rooms', room);
  
  res.status(201).json({
    success: true,
    message: 'Room created successfully',
    data: { room },
    errors: []
  });
});

/**
 * Update room (warden only)
 */
const updateRoom = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { roomNumber, building, capacity, floor, roomType, rent, amenities, isActive } = req.body;
  
  const room = database.getById('rooms', id);
  if (!room) {
    throw new AppError('Room not found', 404, ['Room does not exist']);
  }
  
  // Check if updating room number/building would create a duplicate
  if (roomNumber && building) {
    const existingRoom = database.findBy('rooms', { roomNumber, building })
      .filter(r => r.id !== id)[0];
    if (existingRoom) {
      throw new AppError('Room already exists', 400, ['Room with this number already exists in this building']);
    }
  }
  
  // Check if reducing capacity would exceed current occupancy
  if (capacity !== undefined && capacity < room.capacity) {
    const currentOccupants = database.findBy('students', { roomId: id, isActive: true }).length;
    if (currentOccupants > capacity) {
      throw new AppError('Cannot reduce capacity below current occupancy', 400, [`Room currently has ${currentOccupants} occupants`]);
    }
  }
  
  const updates = {
    updatedAt: new Date().toISOString()
  };
  
  if (roomNumber !== undefined) updates.roomNumber = roomNumber;
  if (building !== undefined) updates.building = building;
  if (capacity !== undefined) updates.capacity = capacity;
  if (floor !== undefined) updates.floor = floor;
  if (roomType !== undefined) updates.roomType = roomType;
  if (rent !== undefined) updates.rent = rent;
  if (amenities !== undefined) updates.amenities = amenities;
  if (isActive !== undefined) updates.isActive = isActive;
  
  database.update('rooms', id, updates);
  
  const updatedRoom = database.getById('rooms', id);
  
  res.json({
    success: true,
    message: 'Room updated successfully',
    data: { room: updatedRoom },
    errors: []
  });
});

/**
 * Delete room (warden only)
 */
const deleteRoom = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const room = database.getById('rooms', id);
  if (!room) {
    throw new AppError('Room not found', 404, ['Room does not exist']);
  }
  
  // Check if room has occupants
  const occupants = database.findBy('students', { roomId: id, isActive: true });
  if (occupants.length > 0) {
    throw new AppError('Cannot delete room with occupants', 400, ['Room has active occupants']);
  }
  
  database.delete('rooms', id);
  
  res.json({
    success: true,
    message: 'Room deleted successfully',
    data: null,
    errors: []
  });
});

/**
 * Get room statistics (warden only)
 */
const getRoomStats = catchAsync(async (req, res, next) => {
  const rooms = database.getAll('rooms');
  const activeRooms = rooms.filter(room => room.isActive);
  
  // Calculate occupancy statistics
  const occupancyStats = {
    totalRooms: activeRooms.length,
    occupiedRooms: 0,
    availableRooms: 0,
    totalCapacity: 0,
    totalOccupied: 0
  };
  
  const roomsByBuilding = {};
  const roomsByType = {};
  
  activeRooms.forEach(room => {
    const occupants = database.findBy('students', { roomId: room.id, isActive: true });
    const occupied = occupants.length;
    
    occupancyStats.totalCapacity += room.capacity;
    occupancyStats.totalOccupied += occupied;
    
    if (occupied > 0) {
      occupancyStats.occupiedRooms++;
    } else {
      occupancyStats.availableRooms++;
    }
    
    // Group by building
    if (!roomsByBuilding[room.building]) {
      roomsByBuilding[room.building] = { total: 0, occupied: 0, available: 0 };
    }
    roomsByBuilding[room.building].total++;
    roomsByBuilding[room.building].occupied += occupied > 0 ? 1 : 0;
    roomsByBuilding[room.building].available += occupied === 0 ? 1 : 0;
    
    // Group by type
    if (!roomsByType[room.roomType]) {
      roomsByType[room.roomType] = { total: 0, occupied: 0, available: 0 };
    }
    roomsByType[room.roomType].total++;
    roomsByType[room.roomType].occupied += occupied > 0 ? 1 : 0;
    roomsByType[room.roomType].available += occupied === 0 ? 1 : 0;
  });
  
  occupancyStats.occupancyRate = occupancyStats.totalCapacity > 0 
    ? (occupancyStats.totalOccupied / occupancyStats.totalCapacity * 100).toFixed(2)
    : 0;
  
  res.json({
    success: true,
    message: 'Room statistics retrieved successfully',
    data: {
      occupancy: occupancyStats,
      byBuilding: roomsByBuilding,
      byType: roomsByType
    },
    errors: []
  });
});

/**
 * Assign student to room (warden only)
 */
const assignStudentToRoom = catchAsync(async (req, res, next) => {
  const { studentId } = req.body;
  const { roomId } = req.params;
  
  const room = database.getById('rooms', roomId);
  if (!room) {
    throw new AppError('Room not found', 404, ['Room does not exist']);
  }
  
  const student = database.getById('students', studentId);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  // Check if student is already assigned to a room
  if (student.roomId) {
    throw new AppError('Student is already assigned to a room', 400, ['Student has existing room assignment']);
  }
  
  // Check room capacity
  const currentOccupants = database.findBy('students', { roomId, isActive: true }).length;
  if (currentOccupants >= room.capacity) {
    throw new AppError('Room is at full capacity', 400, ['Room capacity exceeded']);
  }
  
  // Assign student to room
  database.update('students', studentId, {
    roomId,
    updatedAt: new Date().toISOString()
  });
  
  res.json({
    success: true,
    message: 'Student assigned to room successfully',
    data: null,
    errors: []
  });
});

/**
 * Remove student from room (warden only)
 */
const removeStudentFromRoom = catchAsync(async (req, res, next) => {
  const { studentId } = req.body;
  const { roomId } = req.params;
  
  const room = database.getById('rooms', roomId);
  if (!room) {
    throw new AppError('Room not found', 404, ['Room does not exist']);
  }
  
  const student = database.getById('students', studentId);
  if (!student) {
    throw new AppError('Student not found', 404, ['Student does not exist']);
  }
  
  // Check if student is assigned to this room
  if (student.roomId !== roomId) {
    throw new AppError('Student is not assigned to this room', 400, ['Invalid room assignment']);
  }
  
  // Remove student from room
  database.update('students', studentId, {
    roomId: null,
    updatedAt: new Date().toISOString()
  });
  
  res.json({
    success: true,
    message: 'Student removed from room successfully',
    data: null,
    errors: []
  });
});

module.exports = {
  getAllRooms,
  getRoomById,
  createRoom,
  updateRoom,
  deleteRoom,
  getRoomStats,
  assignStudentToRoom,
  removeStudentFromRoom
};
