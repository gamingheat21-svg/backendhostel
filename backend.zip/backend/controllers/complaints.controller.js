const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all complaints (warden only)
 */
const getAllComplaints = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, status, category, priority, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let complaints = database.getAll('complaints');
  
  // Apply filters
  if (status) {
    complaints = complaints.filter(c => c.status === status);
  }
  
  if (category) {
    complaints = complaints.filter(c => c.category === category);
  }
  
  if (priority) {
    complaints = complaints.filter(c => c.priority === priority);
  }
  
  // Apply sorting
  complaints.sort((a, b) => {
    let aValue = a[sortBy];
    let bValue = b[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedComplaints = complaints.slice(startIndex, endIndex);
  
  // Get student details for each complaint
  const complaintsWithDetails = paginatedComplaints.map(complaint => {
    const student = database.getById('students', complaint.studentId);
    const user = student ? database.getById('users', student.userId) : null;
    
    return {
      ...complaint,
      student: student ? {
        ...student,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName
        } : null
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Complaints retrieved successfully',
    data: {
      complaints: complaintsWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(complaints.length / limit),
        totalComplaints: complaints.length,
        hasNext: endIndex < complaints.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get complaint by ID
 */
const getComplaintById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const complaint = database.getById('complaints', id);
  if (!complaint) {
    throw new AppError('Complaint not found', 404, ['Complaint does not exist']);
  }
  
  const student = database.getById('students', complaint.studentId);
  const user = student ? database.getById('users', student.userId) : null;
  
  res.json({
    success: true,
    message: 'Complaint retrieved successfully',
    data: {
      complaint: {
        ...complaint,
        student: student ? {
          ...student,
          user: user ? {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
          } : null
        } : null
      }
    },
    errors: []
  });
});

/**
 * Create new complaint (student only)
 */
const createComplaint = catchAsync(async (req, res, next) => {
  const { subject, description, category, priority } = req.body;
  const userId = req.user.id;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  const complaint = {
    id: uuidv4(),
    studentId: student.id,
    subject,
    description,
    category,
    priority: priority || 'medium',
    status: 'pending',
    assignedTo: null,
    resolvedBy: null,
    resolvedAt: null,
    resolution: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  database.create('complaints', complaint);
  
  res.status(201).json({
    success: true,
    message: 'Complaint created successfully',
    data: { complaint },
    errors: []
  });
});

/**
 * Update complaint status (warden only)
 */
const updateComplaintStatus = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { status, resolution, assignedTo } = req.body;
  const wardenId = req.user.id;
  
  const complaint = database.getById('complaints', id);
  if (!complaint) {
    throw new AppError('Complaint not found', 404, ['Complaint does not exist']);
  }
  
  if (!['pending', 'in_progress', 'resolved', 'closed'].includes(status)) {
    throw new AppError('Invalid status', 400, ['Status must be pending, in_progress, resolved, or closed']);
  }
  
  const updates = {
    status,
    updatedAt: new Date().toISOString()
  };
  
  if (status === 'resolved' || status === 'closed') {
    updates.resolvedBy = wardenId;
    updates.resolvedAt = new Date().toISOString();
    if (resolution) {
      updates.resolution = resolution;
    }
  }
  
  if (assignedTo) {
    updates.assignedTo = assignedTo;
  }
  
  database.update('complaints', id, updates);
  
  const updatedComplaint = database.getById('complaints', id);
  
  res.json({
    success: true,
    message: 'Complaint status updated successfully',
    data: { complaint: updatedComplaint },
    errors: []
  });
});

/**
 * Get my complaints (student only)
 */
const getMyComplaints = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  const { page = 1, limit = 10, status } = req.query;
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  let complaints = database.findBy('complaints', { studentId: student.id });
  
  // Apply status filter
  if (status) {
    complaints = complaints.filter(c => c.status === status);
  }
  
  // Sort by creation date (newest first)
  complaints.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedComplaints = complaints.slice(startIndex, endIndex);
  
  res.json({
    success: true,
    message: 'My complaints retrieved successfully',
    data: {
      complaints: paginatedComplaints,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(complaints.length / limit),
        totalComplaints: complaints.length,
        hasNext: endIndex < complaints.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Update complaint (student only - limited fields)
 */
const updateMyComplaint = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { subject, description, priority } = req.body;
  const userId = req.user.id;
  
  const complaint = database.getById('complaints', id);
  if (!complaint) {
    throw new AppError('Complaint not found', 404, ['Complaint does not exist']);
  }
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if complaint belongs to the student
  if (complaint.studentId !== student.id) {
    throw new AppError('Access denied', 403, ['You can only update your own complaints']);
  }
  
  // Check if complaint can be updated (only pending complaints)
  if (complaint.status !== 'pending') {
    throw new AppError('Complaint cannot be updated', 400, ['Only pending complaints can be updated']);
  }
  
  const updates = {
    updatedAt: new Date().toISOString()
  };
  
  if (subject !== undefined) updates.subject = subject;
  if (description !== undefined) updates.description = description;
  if (priority !== undefined) updates.priority = priority;
  
  database.update('complaints', id, updates);
  
  const updatedComplaint = database.getById('complaints', id);
  
  res.json({
    success: true,
    message: 'Complaint updated successfully',
    data: { complaint: updatedComplaint },
    errors: []
  });
});

/**
 * Delete complaint (student only)
 */
const deleteMyComplaint = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const userId = req.user.id;
  
  const complaint = database.getById('complaints', id);
  if (!complaint) {
    throw new AppError('Complaint not found', 404, ['Complaint does not exist']);
  }
  
  // Get student profile
  const student = database.findBy('students', { userId })[0];
  if (!student) {
    throw new AppError('Student profile not found', 404, ['Student profile does not exist']);
  }
  
  // Check if complaint belongs to the student
  if (complaint.studentId !== student.id) {
    throw new AppError('Access denied', 403, ['You can only delete your own complaints']);
  }
  
  // Check if complaint can be deleted (only pending complaints)
  if (complaint.status !== 'pending') {
    throw new AppError('Complaint cannot be deleted', 400, ['Only pending complaints can be deleted']);
  }
  
  database.delete('complaints', id);
  
  res.json({
    success: true,
    message: 'Complaint deleted successfully',
    data: null,
    errors: []
  });
});

/**
 * Get complaint statistics (warden only)
 */
const getComplaintStats = catchAsync(async (req, res, next) => {
  const complaints = database.getAll('complaints');
  
  const stats = {
    total: complaints.length,
    pending: 0,
    in_progress: 0,
    resolved: 0,
    closed: 0
  };
  
  const categoryStats = {};
  const priorityStats = {};
  
  complaints.forEach(complaint => {
    stats[complaint.status]++;
    
    // Category stats
    if (!categoryStats[complaint.category]) {
      categoryStats[complaint.category] = 0;
    }
    categoryStats[complaint.category]++;
    
    // Priority stats
    if (!priorityStats[complaint.priority]) {
      priorityStats[complaint.priority] = 0;
    }
    priorityStats[complaint.priority]++;
  });
  
  // Get recent complaints (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentComplaints = complaints.filter(c => 
    new Date(c.createdAt) >= thirtyDaysAgo
  );
  
  // Get overdue complaints (pending for more than 7 days)
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  
  const overdueComplaints = complaints.filter(c => 
    c.status === 'pending' && 
    new Date(c.createdAt) <= sevenDaysAgo
  );
  
  res.json({
    success: true,
    message: 'Complaint statistics retrieved successfully',
    data: {
      overall: stats,
      byCategory: categoryStats,
      byPriority: priorityStats,
      recent: recentComplaints.length,
      overdue: overdueComplaints.length
    },
    errors: []
  });
});

module.exports = {
  getAllComplaints,
  getComplaintById,
  createComplaint,
  updateComplaintStatus,
  getMyComplaints,
  updateMyComplaint,
  deleteMyComplaint,
  getComplaintStats
};
