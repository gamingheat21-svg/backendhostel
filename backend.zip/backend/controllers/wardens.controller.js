const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');
const { AppError, catchAsync } = require('../middlewares/errorHandler');

/**
 * Get all wardens (warden only)
 */
const getAllWardens = catchAsync(async (req, res, next) => {
  const { page = 1, limit = 10, search, sortBy = 'createdAt', sortOrder = 'desc' } = req.query;
  
  let wardens = database.getAll('wardens');
  
  // Apply search filter
  if (search) {
    wardens = wardens.filter(warden => {
      const user = database.getById('users', warden.userId);
      if (!user) return false;
      
      return (
        warden.employeeId.toLowerCase().includes(search.toLowerCase()) ||
        user.firstName.toLowerCase().includes(search.toLowerCase()) ||
        user.lastName.toLowerCase().includes(search.toLowerCase()) ||
        user.email.toLowerCase().includes(search.toLowerCase()) ||
        warden.department.toLowerCase().includes(search.toLowerCase())
      );
    });
  }
  
  // Apply sorting
  wardens.sort((a, b) => {
    let aValue, bValue;
    
    if (sortBy === 'name') {
      const userA = database.getById('users', a.userId);
      const userB = database.getById('users', b.userId);
      aValue = userA ? `${userA.firstName} ${userA.lastName}` : '';
      bValue = userB ? `${userB.firstName} ${userB.lastName}` : '';
    } else {
      aValue = a[sortBy] || '';
      bValue = b[sortBy] || '';
    }
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    } else {
      return aValue < bValue ? 1 : -1;
    }
  });
  
  // Apply pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedWardens = wardens.slice(startIndex, endIndex);
  
  // Get user details for each warden
  const wardensWithDetails = paginatedWardens.map(warden => {
    const user = database.getById('users', warden.userId);
    
    return {
      ...warden,
      user: user ? {
        id: user.id,
        username: user.username,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        isActive: user.isActive,
        createdAt: user.createdAt
      } : null
    };
  });
  
  res.json({
    success: true,
    message: 'Wardens retrieved successfully',
    data: {
      wardens: wardensWithDetails,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(wardens.length / limit),
        totalWardens: wardens.length,
        hasNext: endIndex < wardens.length,
        hasPrev: startIndex > 0
      }
    },
    errors: []
  });
});

/**
 * Get warden by ID
 */
const getWardenById = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  
  const warden = database.getById('wardens', id);
  if (!warden) {
    throw new AppError('Warden not found', 404, ['Warden does not exist']);
  }
  
  const user = database.getById('users', warden.userId);
  
  // Get warden's activity statistics
  const approvedGatePasses = database.findBy('gatePasses', { approvedBy: warden.userId }).length;
  const resolvedComplaints = database.findBy('complaints', { resolvedBy: warden.userId }).length;
  const issuedFines = database.findBy('fines', { issuedBy: warden.userId }).length;
  const processedPayments = database.findBy('payments', { processedBy: warden.userId }).length;
  
  res.json({
    success: true,
    message: 'Warden retrieved successfully',
    data: {
      warden: {
        ...warden,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null,
        activityStats: {
          approvedGatePasses,
          resolvedComplaints,
          issuedFines,
          processedPayments
        }
      }
    },
    errors: []
  });
});

/**
 * Update warden profile (warden only)
 */
const updateWarden = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const { department, phone, isActive } = req.body;
  const currentUserId = req.user.id;
  
  const warden = database.getById('wardens', id);
  if (!warden) {
    throw new AppError('Warden not found', 404, ['Warden does not exist']);
  }
  
  // Check if current user is updating their own profile or is an admin
  if (warden.userId !== currentUserId) {
    // For now, only allow wardens to update their own profile
    // In a real system, you might have admin roles
    throw new AppError('Access denied', 403, ['You can only update your own profile']);
  }
  
  const updates = {
    updatedAt: new Date().toISOString()
  };
  
  if (department !== undefined) updates.department = department;
  if (phone !== undefined) updates.phone = phone;
  if (isActive !== undefined) updates.isActive = isActive;
  
  database.update('wardens', id, updates);
  
  // Get updated warden
  const updatedWarden = database.getById('wardens', id);
  const user = database.getById('users', updatedWarden.userId);
  
  res.json({
    success: true,
    message: 'Warden profile updated successfully',
    data: {
      warden: {
        ...updatedWarden,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null
      }
    },
    errors: []
  });
});

/**
 * Deactivate warden (admin only - for now, any warden can deactivate another)
 */
const deactivateWarden = catchAsync(async (req, res, next) => {
  const { id } = req.params;
  const currentUserId = req.user.id;
  
  const warden = database.getById('wardens', id);
  if (!warden) {
    throw new AppError('Warden not found', 404, ['Warden does not exist']);
  }
  
  // Prevent self-deactivation
  if (warden.userId === currentUserId) {
    throw new AppError('Cannot deactivate yourself', 400, ['Self-deactivation not allowed']);
  }
  
  database.update('wardens', id, {
    isActive: false,
    updatedAt: new Date().toISOString()
  });
  
  // Also deactivate user account
  database.update('users', warden.userId, {
    isActive: false,
    updatedAt: new Date().toISOString()
  });
  
  res.json({
    success: true,
    message: 'Warden deactivated successfully',
    data: null,
    errors: []
  });
});

/**
 * Get warden statistics (warden only)
 */
const getWardenStats = catchAsync(async (req, res, next) => {
  const wardens = database.getAll('wardens');
  const activeWardens = wardens.filter(w => w.isActive);
  const inactiveWardens = wardens.filter(w => !w.isActive);
  
  // Get department statistics
  const departmentStats = {};
  activeWardens.forEach(warden => {
    const department = warden.department;
    departmentStats[department] = (departmentStats[department] || 0) + 1;
  });
  
  // Get activity statistics for all wardens
  const activityStats = wardens.map(warden => {
    const user = database.getById('users', warden.userId);
    const approvedGatePasses = database.findBy('gatePasses', { approvedBy: warden.userId }).length;
    const resolvedComplaints = database.findBy('complaints', { resolvedBy: warden.userId }).length;
    const issuedFines = database.findBy('fines', { issuedBy: warden.userId }).length;
    const processedPayments = database.findBy('payments', { processedBy: warden.userId }).length;
    
    return {
      wardenId: warden.id,
      employeeId: warden.employeeId,
      name: user ? `${user.firstName} ${user.lastName}` : 'Unknown',
      department: warden.department,
      approvedGatePasses,
      resolvedComplaints,
      issuedFines,
      processedPayments,
      totalActivity: approvedGatePasses + resolvedComplaints + issuedFines + processedPayments
    };
  });
  
  // Sort by total activity
  activityStats.sort((a, b) => b.totalActivity - a.totalActivity);
  
  res.json({
    success: true,
    message: 'Warden statistics retrieved successfully',
    data: {
      totalWardens: wardens.length,
      activeWardens: activeWardens.length,
      inactiveWardens: inactiveWardens.length,
      departmentStats,
      activityStats: activityStats.slice(0, 10) // Top 10 most active wardens
    },
    errors: []
  });
});

/**
 * Get my profile (warden only)
 */
const getMyProfile = catchAsync(async (req, res, next) => {
  const userId = req.user.id;
  
  const warden = database.findBy('wardens', { userId })[0];
  if (!warden) {
    throw new AppError('Warden profile not found', 404, ['Warden profile does not exist']);
  }
  
  const user = database.getById('users', userId);
  
  // Get recent activities
  const recentGatePasses = database.findBy('gatePasses', { approvedBy: userId })
    .sort((a, b) => new Date(b.approvedAt) - new Date(a.approvedAt))
    .slice(0, 5);
  
  const recentComplaints = database.findBy('complaints', { resolvedBy: userId })
    .sort((a, b) => new Date(b.resolvedAt) - new Date(a.resolvedAt))
    .slice(0, 5);
  
  const recentFines = database.findBy('fines', { issuedBy: userId })
    .sort((a, b) => new Date(b.issuedAt) - new Date(a.issuedAt))
    .slice(0, 5);
  
  const recentPayments = database.findBy('payments', { processedBy: userId })
    .sort((a, b) => new Date(b.processedAt) - new Date(a.processedAt))
    .slice(0, 5);
  
  // Get pending items that need attention
  const pendingGatePasses = database.findBy('gatePasses', { status: 'pending' }).length;
  const pendingComplaints = database.findBy('complaints', { status: 'pending' }).length;
  const pendingPayments = database.findBy('payments', { status: 'pending' }).length;
  
  res.json({
    success: true,
    message: 'Profile retrieved successfully',
    data: {
      warden: {
        ...warden,
        user: user ? {
          id: user.id,
          username: user.username,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          isActive: user.isActive,
          createdAt: user.createdAt
        } : null
      },
      recentActivities: {
        recentGatePasses,
        recentComplaints,
        recentFines,
        recentPayments
      },
      pendingItems: {
        pendingGatePasses,
        pendingComplaints,
        pendingPayments,
        totalPending: pendingGatePasses + pendingComplaints + pendingPayments
      }
    },
    errors: []
  });
});

/**
 * Get dashboard data (warden only)
 */
const getDashboardData = catchAsync(async (req, res, next) => {
  // Get counts for various entities
  const totalStudents = database.findBy('students', { isActive: true }).length;
  const totalRooms = database.findBy('rooms', { isActive: true }).length;
  const occupiedRooms = database.findBy('rooms', { isActive: true }).filter(room => {
    const occupants = database.findBy('students', { roomId: room.id, isActive: true });
    return occupants.length > 0;
  }).length;
  
  // Get pending items
  const pendingGatePasses = database.findBy('gatePasses', { status: 'pending' }).length;
  const pendingComplaints = database.findBy('complaints', { status: 'pending' }).length;
  const pendingPayments = database.findBy('payments', { status: 'pending' }).length;
  const pendingFines = database.findBy('fines', { status: 'pending' }).length;
  
  // Get recent activities (last 7 days)
  const sevenDaysAgo = new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  
  const recentGatePasses = database.findBy('gatePasses', {}).filter(gp => 
    new Date(gp.createdAt) >= sevenDaysAgo
  ).length;
  
  const recentComplaints = database.findBy('complaints', {}).filter(c => 
    new Date(c.createdAt) >= sevenDaysAgo
  ).length;
  
  const recentFines = database.findBy('fines', {}).filter(f => 
    new Date(f.createdAt) >= sevenDaysAgo
  ).length;
  
  const recentPayments = database.findBy('payments', {}).filter(p => 
    new Date(p.createdAt) >= sevenDaysAgo
  ).length;
  
  // Get overdue items
  const overdueGatePasses = database.findBy('gatePasses', { status: 'approved' }).filter(gp => 
    new Date(gp.expectedReturnTime) < new Date()
  ).length;
  
  const overdueComplaints = database.findBy('complaints', { status: 'pending' }).filter(c => {
    const complaintDate = new Date(c.createdAt);
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    return complaintDate <= thirtyDaysAgo;
  }).length;
  
  res.json({
    success: true,
    message: 'Dashboard data retrieved successfully',
    data: {
      overview: {
        totalStudents,
        totalRooms,
        occupiedRooms,
        availableRooms: totalRooms - occupiedRooms
      },
      pendingItems: {
        gatePasses: pendingGatePasses,
        complaints: pendingComplaints,
        payments: pendingPayments,
        fines: pendingFines,
        total: pendingGatePasses + pendingComplaints + pendingPayments + pendingFines
      },
      recentActivity: {
        gatePasses: recentGatePasses,
        complaints: recentComplaints,
        fines: recentFines,
        payments: recentPayments
      },
      overdueItems: {
        gatePasses: overdueGatePasses,
        complaints: overdueComplaints
      }
    },
    errors: []
  });
});

module.exports = {
  getAllWardens,
  getWardenById,
  updateWarden,
  deactivateWarden,
  getWardenStats,
  getMyProfile,
  getDashboardData
};
