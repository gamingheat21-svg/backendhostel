const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const database = require('../config/db');

/**
 * Seed script to populate the database with sample data
 */

const seedData = async () => {
  try {
    console.log('🌱 Starting database seeding...');

    // Initialize database
    database.init();

    // Clear existing data
    console.log('🧹 Clearing existing data...');
    database.getDB().set('users', []).write();
    database.getDB().set('students', []).write();
    database.getDB().set('wardens', []).write();
    database.getDB().set('rooms', []).write();
    database.getDB().set('gatePasses', []).write();
    database.getDB().set('complaints', []).write();
    database.getDB().set('fines', []).write();
    database.getDB().set('payments', []).write();

    // Create wardens
    console.log('👨‍💼 Creating wardens...');
    const wardens = [
      {
        id: uuidv4(),
        username: 'admin',
        email: 'admin@hostel.com',
        password: await bcrypt.hash('admin123', 12),
        role: 'warden',
        firstName: 'Admin',
        lastName: 'Warden',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'john_warden',
        email: 'john.warden@hostel.com',
        password: await bcrypt.hash('warden123', 12),
        role: 'warden',
        firstName: 'John',
        lastName: 'Smith',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'mary_warden',
        email: 'mary.warden@hostel.com',
        password: await bcrypt.hash('warden123', 12),
        role: 'warden',
        firstName: 'Mary',
        lastName: 'Johnson',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    const wardenProfiles = [
      {
        id: uuidv4(),
        userId: wardens[0].id,
        employeeId: 'EMP001',
        department: 'Administration',
        phone: '+1234567890',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: wardens[1].id,
        employeeId: 'EMP002',
        department: 'Security',
        phone: '+1234567891',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: wardens[2].id,
        employeeId: 'EMP003',
        department: 'Maintenance',
        phone: '+1234567892',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    wardens.forEach(warden => database.create('users', warden));
    wardenProfiles.forEach(profile => database.create('wardens', profile));

    // Create students
    console.log('👨‍🎓 Creating students...');
    const students = [
      {
        id: uuidv4(),
        username: 'alice_student',
        email: 'alice.student@university.edu',
        password: await bcrypt.hash('student123', 12),
        role: 'student',
        firstName: 'Alice',
        lastName: 'Johnson',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'bob_student',
        email: 'bob.student@university.edu',
        password: await bcrypt.hash('student123', 12),
        role: 'student',
        firstName: 'Bob',
        lastName: 'Smith',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'charlie_student',
        email: 'charlie.student@university.edu',
        password: await bcrypt.hash('student123', 12),
        role: 'student',
        firstName: 'Charlie',
        lastName: 'Brown',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'diana_student',
        email: 'diana.student@university.edu',
        password: await bcrypt.hash('student123', 12),
        role: 'student',
        firstName: 'Diana',
        lastName: 'Wilson',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        username: 'eve_student',
        email: 'eve.student@university.edu',
        password: await bcrypt.hash('student123', 12),
        role: 'student',
        firstName: 'Eve',
        lastName: 'Davis',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    const studentProfiles = [
      {
        id: uuidv4(),
        userId: students[0].id,
        studentId: 'STU001',
        course: 'Computer Science',
        year: 2,
        phone: '+1234567893',
        roomId: null,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: students[1].id,
        studentId: 'STU002',
        course: 'Engineering',
        year: 3,
        phone: '+1234567894',
        roomId: null,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: students[2].id,
        studentId: 'STU003',
        course: 'Business Administration',
        year: 1,
        phone: '+1234567895',
        roomId: null,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: students[3].id,
        studentId: 'STU004',
        course: 'Medicine',
        year: 4,
        phone: '+1234567896',
        roomId: null,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        userId: students[4].id,
        studentId: 'STU005',
        course: 'Arts',
        year: 2,
        phone: '+1234567897',
        roomId: null,
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    students.forEach(student => database.create('users', student));
    studentProfiles.forEach(profile => database.create('students', profile));

    // Create rooms
    console.log('🏠 Creating rooms...');
    const rooms = [
      {
        id: uuidv4(),
        roomNumber: '101',
        building: 'Block A',
        capacity: 2,
        floor: 1,
        roomType: 'double',
        rent: 5000,
        amenities: ['WiFi', 'Air Conditioning', 'Study Table'],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        roomNumber: '102',
        building: 'Block A',
        capacity: 2,
        floor: 1,
        roomType: 'double',
        rent: 5000,
        amenities: ['WiFi', 'Air Conditioning'],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        roomNumber: '201',
        building: 'Block A',
        capacity: 1,
        floor: 2,
        roomType: 'single',
        rent: 8000,
        amenities: ['WiFi', 'Air Conditioning', 'Study Table', 'Private Bathroom'],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        roomNumber: '301',
        building: 'Block B',
        capacity: 3,
        floor: 3,
        roomType: 'triple',
        rent: 4000,
        amenities: ['WiFi', 'Study Table'],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        roomNumber: '401',
        building: 'Block B',
        capacity: 4,
        floor: 4,
        roomType: 'quad',
        rent: 3000,
        amenities: ['WiFi'],
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    rooms.forEach(room => database.create('rooms', room));

    // Assign students to rooms
    console.log('🏠 Assigning students to rooms...');
    const studentProfilesList = database.getAll('students');
    const roomsList = database.getAll('rooms');

    // Assign Alice and Bob to room 101
    database.update('students', studentProfilesList[0].id, { roomId: roomsList[0].id });
    database.update('students', studentProfilesList[1].id, { roomId: roomsList[0].id });

    // Assign Charlie to room 201
    database.update('students', studentProfilesList[2].id, { roomId: roomsList[2].id });

    // Create sample gate passes
    console.log('🚪 Creating sample gate passes...');
    const gatePasses = [
      {
        id: uuidv4(),
        studentId: studentProfilesList[0].id,
        reason: 'Going home for weekend to visit family',
        destination: 'New York',
        departureTime: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow
        expectedReturnTime: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days from now
        emergencyContact: '+1234567898',
        status: 'pending',
        approvedBy: null,
        approvedAt: null,
        rejectionReason: null,
        actualReturnTime: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        studentId: studentProfilesList[1].id,
        reason: 'Medical appointment at city hospital',
        destination: 'City Hospital',
        departureTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
        expectedReturnTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // 4 hours from now
        emergencyContact: '+1234567899',
        status: 'approved',
        approvedBy: wardens[0].id,
        approvedAt: new Date().toISOString(),
        rejectionReason: null,
        actualReturnTime: null,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
        updatedAt: new Date().toISOString()
      }
    ];

    gatePasses.forEach(gatePass => database.create('gatePasses', gatePass));

    // Create sample complaints
    console.log('📝 Creating sample complaints...');
    const complaints = [
      {
        id: uuidv4(),
        studentId: studentProfilesList[2].id,
        subject: 'WiFi not working in room 201',
        description: 'The WiFi connection in my room has been very poor for the past week. I cannot access online classes properly.',
        category: 'maintenance',
        priority: 'high',
        status: 'pending',
        assignedTo: null,
        resolvedBy: null,
        resolvedAt: null,
        resolution: null,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        studentId: studentProfilesList[0].id,
        subject: 'Noisy neighbors in room 102',
        description: 'The students in room 102 are very loud during night hours, making it difficult to sleep.',
        category: 'noise',
        priority: 'medium',
        status: 'in_progress',
        assignedTo: wardens[1].id,
        resolvedBy: null,
        resolvedAt: null,
        resolution: null,
        createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
        updatedAt: new Date().toISOString()
      }
    ];

    complaints.forEach(complaint => database.create('complaints', complaint));

    // Create sample fines
    console.log('💰 Creating sample fines...');
    const fines = [
      {
        id: uuidv4(),
        studentId: studentProfilesList[3].id,
        reason: 'Late return from gate pass - returned 2 hours after expected time',
        amount: 500,
        fineType: 'late_return',
        status: 'pending',
        issuedBy: wardens[0].id,
        issuedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
        paidAt: null,
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        studentId: studentProfilesList[4].id,
        reason: 'Damage to room furniture - broken study table',
        amount: 2000,
        fineType: 'damage',
        status: 'pending',
        issuedBy: wardens[2].id,
        issuedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
        paidAt: null,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];

    fines.forEach(fine => database.create('fines', fine));

    // Create sample payments
    console.log('💳 Creating sample payments...');
    const payments = [
      {
        id: uuidv4(),
        studentId: studentProfilesList[0].id,
        amount: 5000,
        paymentType: 'rent',
        description: 'Rent for October 2024',
        fineId: null,
        status: 'approved',
        receiptNumber: 'RCP-001',
        processedBy: wardens[0].id,
        processedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), // 1 week ago
        createdAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000).toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        studentId: studentProfilesList[1].id,
        amount: 5000,
        paymentType: 'rent',
        description: 'Rent for October 2024',
        fineId: null,
        status: 'pending',
        receiptNumber: null,
        processedBy: null,
        processedAt: null,
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
        updatedAt: new Date().toISOString()
      }
    ];

    payments.forEach(payment => database.create('payments', payment));

    // Update settings
    database.updateSettings({
      lastSeeded: new Date().toISOString(),
      seedVersion: '1.0.0'
    });

    console.log('✅ Database seeding completed successfully!');
    console.log('\n📊 Seeded data summary:');
    console.log(`• Users: ${database.getAll('users').length}`);
    console.log(`• Students: ${database.getAll('students').length}`);
    console.log(`• Wardens: ${database.getAll('wardens').length}`);
    console.log(`• Rooms: ${database.getAll('rooms').length}`);
    console.log(`• Gate Passes: ${database.getAll('gatePasses').length}`);
    console.log(`• Complaints: ${database.getAll('complaints').length}`);
    console.log(`• Fines: ${database.getAll('fines').length}`);
    console.log(`• Payments: ${database.getAll('payments').length}`);

    console.log('\n🔐 Default login credentials:');
    console.log('Wardens:');
    console.log('  admin@hostel.com / admin123');
    console.log('  john.warden@hostel.com / warden123');
    console.log('  mary.warden@hostel.com / warden123');
    console.log('\nStudents:');
    console.log('  alice.student@university.edu / student123');
    console.log('  bob.student@university.edu / student123');
    console.log('  charlie.student@university.edu / student123');
    console.log('  diana.student@university.edu / student123');
    console.log('  eve.student@university.edu / student123');

  } catch (error) {
    console.error('❌ Error seeding database:', error);
    process.exit(1);
  }
};

// Run seeding if this file is executed directly
if (require.main === module) {
  seedData().then(() => {
    console.log('\n🎉 Seeding process completed!');
    process.exit(0);
  }).catch((error) => {
    console.error('💥 Seeding failed:', error);
    process.exit(1);
  });
}

module.exports = seedData;
