const lowdb = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');

/**
 * Database configuration using lowdb for JSON file storage
 * Provides thread-safe read/write operations with locking
 */

class Database {
  constructor() {
    this.db = null;
    this.initialized = false;
  }

  /**
   * Initialize the database connection
   */
  init() {
    try {
      const dbPath = process.env.DB_PATH || './db.json';
      const adapter = new FileSync(dbPath);
      this.db = lowdb(adapter);

      // Set default values if database is empty
      this.db.defaults({
        users: [],
        students: [],
        wardens: [],
        rooms: [],
        gatePasses: [],
        complaints: [],
        fines: [],
        payments: [],
        settings: {
          lastUpdated: new Date().toISOString()
        }
      }).write();

      this.initialized = true;
      console.log('✅ Database initialized successfully');
    } catch (error) {
      console.error('❌ Database initialization failed:', error);
      throw error;
    }
  }

  /**
   * Get database instance
   */
  getDB() {
    if (!this.initialized) {
      this.init();
    }
    return this.db;
  }

  /**
   * Safe write operation with error handling
   */
  safeWrite(operation) {
    try {
      return operation();
    } catch (error) {
      console.error('Database write error:', error);
      throw new Error('Database operation failed');
    }
  }

  /**
   * Safe read operation with error handling
   */
  safeRead(operation) {
    try {
      return operation();
    } catch (error) {
      console.error('Database read error:', error);
      throw new Error('Database read failed');
    }
  }

  /**
   * Get all records from a collection
   */
  getAll(collection) {
    return this.safeRead(() => this.getDB().get(collection).value());
  }

  /**
   * Get a record by ID from a collection
   */
  getById(collection, id) {
    return this.safeRead(() => 
      this.getDB().get(collection).find({ id }).value()
    );
  }

  /**
   * Create a new record in a collection
   */
  create(collection, data) {
    return this.safeWrite(() => 
      this.getDB().get(collection).push(data).write()
    );
  }

  /**
   * Update a record by ID in a collection
   */
  update(collection, id, updates) {
    return this.safeWrite(() => 
      this.getDB().get(collection).find({ id }).assign(updates).write()
    );
  }

  /**
   * Delete a record by ID from a collection
   */
  delete(collection, id) {
    return this.safeWrite(() => 
      this.getDB().get(collection).remove({ id }).write()
    );
  }

  /**
   * Find records by condition
   */
  findBy(collection, condition) {
    return this.safeRead(() => 
      this.getDB().get(collection).filter(condition).value()
    );
  }

  /**
   * Get count of records in a collection
   */
  count(collection) {
    return this.safeRead(() => 
      this.getDB().get(collection).size().value()
    );
  }

  /**
   * Update settings
   */
  updateSettings(updates) {
    return this.safeWrite(() => 
      this.getDB().get('settings').assign({
        ...updates,
        lastUpdated: new Date().toISOString()
      }).write()
    );
  }
}

// Export singleton instance
const database = new Database();
module.exports = database;
