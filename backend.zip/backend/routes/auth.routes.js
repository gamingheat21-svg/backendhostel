const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller');
const { authenticateToken } = require('../middlewares/auth');
const { validateRequest } = require('../middlewares/errorHandler');
const {
  validateUserRegistration,
  validateUserLogin,
  validateStudentRegistration,
  validateWardenRegistration,
  sanitizeInput
} = require('../utils/validators');

/**
 * @route   POST /api/auth/register/student
 * @desc    Register a new student
 * @access  Public
 */
router.post('/register/student', 
  sanitizeInput,
  validateRequest(validateStudentRegistration),
  authController.register
);

/**
 * @route   POST /api/auth/register/warden
 * @desc    Register a new warden
 * @access  Public
 */
router.post('/register/warden', 
  sanitizeInput,
  validateRequest(validateWardenRegistration),
  authController.register
);

/**
 * @route   POST /api/auth/login
 * @desc    Login user
 * @access  Public
 */
router.post('/login', 
  sanitizeInput,
  validateRequest(validateUserLogin),
  authController.login
);

/**
 * @route   GET /api/auth/profile
 * @desc    Get current user profile
 * @access  Private
 */
router.get('/profile', 
  authenticateToken,
  authController.getProfile
);

/**
 * @route   PUT /api/auth/profile
 * @desc    Update current user profile
 * @access  Private
 */
router.put('/profile', 
  authenticateToken,
  sanitizeInput,
  authController.updateProfile
);

/**
 * @route   PUT /api/auth/change-password
 * @desc    Change user password
 * @access  Private
 */
router.put('/change-password', 
  authenticateToken,
  sanitizeInput,
  authController.changePassword
);

/**
 * @route   POST /api/auth/logout
 * @desc    Logout user (client-side token removal)
 * @access  Private
 */
router.post('/logout', 
  authenticateToken,
  authController.logout
);

module.exports = router;
