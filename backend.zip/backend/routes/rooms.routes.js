const express = require('express');
const router = express.Router();
const roomsController = require('../controllers/rooms.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireWardenOrStudent } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateRoom, validateId, validatePagination, validateSearch, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/rooms
 * @desc    Get all rooms
 * @access  Private (Warden or Student)
 */
router.get('/',
  authenticateToken,
  requireWardenOrStudent,
  validateRequest([...validatePagination, ...validateSearch]),
  roomsController.getAllRooms
);

/**
 * @route   GET /api/rooms/stats
 * @desc    Get room statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  roomsController.getRoomStats
);

/**
 * @route   GET /api/rooms/:id
 * @desc    Get room by ID
 * @access  Private (Warden or Student)
 */
router.get('/:id',
  authenticateToken,
  requireWardenOrStudent,
  validateRequest(validateId),
  roomsController.getRoomById
);

/**
 * @route   POST /api/rooms
 * @desc    Create new room (warden only)
 * @access  Private (Warden)
 */
router.post('/',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateRoom),
  roomsController.createRoom
);

/**
 * @route   PUT /api/rooms/:id
 * @desc    Update room (warden only)
 * @access  Private (Warden)
 */
router.put('/:id',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  roomsController.updateRoom
);

/**
 * @route   DELETE /api/rooms/:id
 * @desc    Delete room (warden only)
 * @access  Private (Warden)
 */
router.delete('/:id',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  roomsController.deleteRoom
);

/**
 * @route   POST /api/rooms/:roomId/assign
 * @desc    Assign student to room (warden only)
 * @access  Private (Warden)
 */
router.post('/:roomId/assign',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  roomsController.assignStudentToRoom
);

/**
 * @route   POST /api/rooms/:roomId/remove
 * @desc    Remove student from room (warden only)
 * @access  Private (Warden)
 */
router.post('/:roomId/remove',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  roomsController.removeStudentFromRoom
);

module.exports = router;
