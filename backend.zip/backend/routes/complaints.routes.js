const express = require('express');
const router = express.Router();
const complaintsController = require('../controllers/complaints.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireStudent, requireOwnershipOrWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateComplaint, validateId, validatePagination, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/complaints
 * @desc    Get all complaints (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest(validatePagination),
  complaintsController.getAllComplaints
);

/**
 * @route   GET /api/complaints/stats
 * @desc    Get complaint statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  complaintsController.getComplaintStats
);

/**
 * @route   GET /api/complaints/my-complaints
 * @desc    Get my complaints (student only)
 * @access  Private (Student)
 */
router.get('/my-complaints',
  authenticateToken,
  requireStudent,
  validateRequest(validatePagination),
  complaintsController.getMyComplaints
);

/**
 * @route   GET /api/complaints/:id
 * @desc    Get complaint by ID
 * @access  Private (Warden or Student - own complaint)
 */
router.get('/:id',
  authenticateToken,
  requireOwnershipOrWarden('studentId'),
  validateRequest(validateId),
  complaintsController.getComplaintById
);

/**
 * @route   POST /api/complaints
 * @desc    Create new complaint (student only)
 * @access  Private (Student)
 */
router.post('/',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  validateRequest(validateComplaint),
  complaintsController.createComplaint
);

/**
 * @route   PUT /api/complaints/:id/status
 * @desc    Update complaint status (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/status',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  complaintsController.updateComplaintStatus
);

/**
 * @route   PUT /api/complaints/:id
 * @desc    Update complaint (student only - limited fields)
 * @access  Private (Student)
 */
router.put('/:id',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  validateRequest(validateId),
  complaintsController.updateMyComplaint
);

/**
 * @route   DELETE /api/complaints/:id
 * @desc    Delete complaint (student only)
 * @access  Private (Student)
 */
router.delete('/:id',
  authenticateToken,
  requireStudent,
  validateRequest(validateId),
  complaintsController.deleteMyComplaint
);

module.exports = router;
