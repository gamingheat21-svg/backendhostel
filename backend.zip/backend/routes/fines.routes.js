const express = require('express');
const router = express.Router();
const finesController = require('../controllers/fines.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireStudent, requireOwnershipOrWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateFine, validateId, validatePagination, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/fines
 * @desc    Get all fines (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest(validatePagination),
  finesController.getAllFines
);

/**
 * @route   GET /api/fines/stats
 * @desc    Get fine statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  finesController.getFineStats
);

/**
 * @route   GET /api/fines/my-fines
 * @desc    Get my fines (student only)
 * @access  Private (Student)
 */
router.get('/my-fines',
  authenticateToken,
  requireStudent,
  validateRequest(validatePagination),
  finesController.getMyFines
);

/**
 * @route   GET /api/fines/:id
 * @desc    Get fine by ID
 * @access  Private (Warden or Student - own fine)
 */
router.get('/:id',
  authenticateToken,
  requireOwnershipOrWarden('studentId'),
  validateRequest(validateId),
  finesController.getFineById
);

/**
 * @route   POST /api/fines
 * @desc    Create new fine (warden only)
 * @access  Private (Warden)
 */
router.post('/',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateFine),
  finesController.createFine
);

/**
 * @route   POST /api/fines/bulk
 * @desc    Create multiple fines (warden only)
 * @access  Private (Warden)
 */
router.post('/bulk',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  finesController.bulkCreateFines
);

/**
 * @route   PUT /api/fines/:id/status
 * @desc    Update fine status (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/status',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  finesController.updateFineStatus
);

/**
 * @route   PUT /api/fines/:id/waiver
 * @desc    Request fine waiver (student only)
 * @access  Private (Student)
 */
router.put('/:id/waiver',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  validateRequest(validateId),
  finesController.requestFineWaiver
);

module.exports = router;
