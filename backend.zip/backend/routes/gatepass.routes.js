const express = require('express');
const router = express.Router();
const gatePassController = require('../controllers/gatepass.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireStudent, requireOwnershipOrWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateGatePass, validateId, validatePagination, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/gatepasses
 * @desc    Get all gate passes (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest(validatePagination),
  gatePassController.getAllGatePasses
);

/**
 * @route   GET /api/gatepasses/stats
 * @desc    Get gate pass statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  gatePassController.getGatePassStats
);

/**
 * @route   GET /api/gatepasses/my-passes
 * @desc    Get my gate passes (student only)
 * @access  Private (Student)
 */
router.get('/my-passes',
  authenticateToken,
  requireStudent,
  validateRequest(validatePagination),
  gatePassController.getMyGatePasses
);

/**
 * @route   GET /api/gatepasses/:id
 * @desc    Get gate pass by ID
 * @access  Private (Warden or Student - own gate pass)
 */
router.get('/:id',
  authenticateToken,
  requireOwnershipOrWarden('studentId'),
  validateRequest(validateId),
  gatePassController.getGatePassById
);

/**
 * @route   POST /api/gatepasses
 * @desc    Create new gate pass (student only)
 * @access  Private (Student)
 */
router.post('/',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  validateRequest(validateGatePass),
  gatePassController.createGatePass
);

/**
 * @route   PUT /api/gatepasses/:id/approve
 * @desc    Approve gate pass (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/approve',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  gatePassController.approveGatePass
);

/**
 * @route   PUT /api/gatepasses/:id/reject
 * @desc    Reject gate pass (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/reject',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  gatePassController.rejectGatePass
);

/**
 * @route   PUT /api/gatepasses/:id/return
 * @desc    Mark gate pass as returned (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/return',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  gatePassController.markGatePassReturned
);

/**
 * @route   PUT /api/gatepasses/:id/cancel
 * @desc    Cancel gate pass (student only)
 * @access  Private (Student)
 */
router.put('/:id/cancel',
  authenticateToken,
  requireStudent,
  validateRequest(validateId),
  gatePassController.cancelGatePass
);

module.exports = router;
