const express = require('express');
const router = express.Router();
const wardensController = require('../controllers/wardens.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateId, validatePagination, validateSearch, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/wardens
 * @desc    Get all wardens (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest([...validatePagination, ...validateSearch]),
  wardensController.getAllWardens
);

/**
 * @route   GET /api/wardens/stats
 * @desc    Get warden statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  wardensController.getWardenStats
);

/**
 * @route   GET /api/wardens/dashboard
 * @desc    Get dashboard data (warden only)
 * @access  Private (Warden)
 */
router.get('/dashboard',
  authenticateToken,
  requireWarden,
  wardensController.getDashboardData
);

/**
 * @route   GET /api/wardens/my-profile
 * @desc    Get my warden profile
 * @access  Private (Warden)
 */
router.get('/my-profile',
  authenticateToken,
  requireWarden,
  wardensController.getMyProfile
);

/**
 * @route   GET /api/wardens/:id
 * @desc    Get warden by ID
 * @access  Private (Warden)
 */
router.get('/:id',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  wardensController.getWardenById
);

/**
 * @route   PUT /api/wardens/:id
 * @desc    Update warden profile
 * @access  Private (Warden)
 */
router.put('/:id',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  wardensController.updateWarden
);

/**
 * @route   DELETE /api/wardens/:id
 * @desc    Deactivate warden
 * @access  Private (Warden)
 */
router.delete('/:id',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  wardensController.deactivateWarden
);

module.exports = router;
