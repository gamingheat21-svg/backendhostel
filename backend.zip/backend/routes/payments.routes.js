const express = require('express');
const router = express.Router();
const paymentsController = require('../controllers/payments.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireStudent, requireOwnershipOrWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validatePayment, validateId, validatePagination, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/payments
 * @desc    Get all payments (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest(validatePagination),
  paymentsController.getAllPayments
);

/**
 * @route   GET /api/payments/stats
 * @desc    Get payment statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  paymentsController.getPaymentStats
);

/**
 * @route   GET /api/payments/my-payments
 * @desc    Get my payments (student only)
 * @access  Private (Student)
 */
router.get('/my-payments',
  authenticateToken,
  requireStudent,
  validateRequest(validatePagination),
  paymentsController.getMyPayments
);

/**
 * @route   GET /api/payments/:id
 * @desc    Get payment by ID
 * @access  Private (Warden or Student - own payment)
 */
router.get('/:id',
  authenticateToken,
  requireOwnershipOrWarden('studentId'),
  validateRequest(validateId),
  paymentsController.getPaymentById
);

/**
 * @route   GET /api/payments/:id/receipt
 * @desc    Generate payment receipt (warden only)
 * @access  Private (Warden)
 */
router.get('/:id/receipt',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  paymentsController.generateReceipt
);

/**
 * @route   POST /api/payments
 * @desc    Create new payment request (student only)
 * @access  Private (Student)
 */
router.post('/',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  validateRequest(validatePayment),
  paymentsController.createPaymentRequest
);

/**
 * @route   POST /api/payments/rent
 * @desc    Create rent payment request (student only)
 * @access  Private (Student)
 */
router.post('/rent',
  authenticateToken,
  requireStudent,
  sanitizeInput,
  paymentsController.createRentPaymentRequest
);

/**
 * @route   PUT /api/payments/:id/process
 * @desc    Process payment (warden only)
 * @access  Private (Warden)
 */
router.put('/:id/process',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  paymentsController.processPayment
);

module.exports = router;
