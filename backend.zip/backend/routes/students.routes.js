const express = require('express');
const router = express.Router();
const studentsController = require('../controllers/students.controller');
const { authenticateToken } = require('../middlewares/auth');
const { requireWarden, requireStudent, requireOwnershipOrWarden } = require('../middlewares/role');
const { validateRequest } = require('../middlewares/errorHandler');
const { validateId, validatePagination, validateSearch, sanitizeInput } = require('../utils/validators');

/**
 * @route   GET /api/students
 * @desc    Get all students (warden only)
 * @access  Private (Warden)
 */
router.get('/',
  authenticateToken,
  requireWarden,
  validateRequest([...validatePagination, ...validateSearch]),
  studentsController.getAllStudents
);

/**
 * @route   GET /api/students/stats
 * @desc    Get student statistics (warden only)
 * @access  Private (Warden)
 */
router.get('/stats',
  authenticateToken,
  requireWarden,
  studentsController.getStudentStats
);

/**
 * @route   GET /api/students/my-profile
 * @desc    Get my student profile
 * @access  Private (Student)
 */
router.get('/my-profile',
  authenticateToken,
  requireStudent,
  studentsController.getMyProfile
);

/**
 * @route   GET /api/students/:id
 * @desc    Get student by ID
 * @access  Private (Warden or Student - own profile)
 */
router.get('/:id',
  authenticateToken,
  requireOwnershipOrWarden('id'),
  validateRequest(validateId),
  studentsController.getStudentById
);

/**
 * @route   PUT /api/students/:id
 * @desc    Update student profile (warden only)
 * @access  Private (Warden)
 */
router.put('/:id',
  authenticateToken,
  requireWarden,
  sanitizeInput,
  validateRequest(validateId),
  studentsController.updateStudent
);

/**
 * @route   DELETE /api/students/:id
 * @desc    Deactivate student (warden only)
 * @access  Private (Warden)
 */
router.delete('/:id',
  authenticateToken,
  requireWarden,
  validateRequest(validateId),
  studentsController.deactivateStudent
);

module.exports = router;
