const { body, param, query } = require('express-validator');
const bcrypt = require('bcryptjs');

/**
 * Validation rules for user registration and login
 */
const validateUserRegistration = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
  
  body('role')
    .isIn(['student', 'warden'])
    .withMessage('Role must be either student or warden'),
  
  body('firstName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('First name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('First name can only contain letters and spaces'),
  
  body('lastName')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Last name must be between 2 and 50 characters')
    .matches(/^[a-zA-Z\s]+$/)
    .withMessage('Last name can only contain letters and spaces')
];

const validateUserLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required')
];

/**
 * Validation rules for student-specific fields
 */
const validateStudentRegistration = [
  ...validateUserRegistration,
  body('studentId')
    .trim()
    .isLength({ min: 5, max: 20 })
    .withMessage('Student ID must be between 5 and 20 characters')
    .matches(/^[A-Za-z0-9]+$/)
    .withMessage('Student ID can only contain letters and numbers'),
  
  body('course')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Course must be between 2 and 100 characters'),
  
  body('year')
    .isInt({ min: 1, max: 10 })
    .withMessage('Year must be a number between 1 and 10'),
  
  body('phone')
    .optional()
    .isMobilePhone()
    .withMessage('Please provide a valid phone number')
];

/**
 * Validation rules for warden-specific fields
 */
const validateWardenRegistration = [
  ...validateUserRegistration,
  body('employeeId')
    .trim()
    .isLength({ min: 5, max: 20 })
    .withMessage('Employee ID must be between 5 and 20 characters')
    .matches(/^[A-Za-z0-9]+$/)
    .withMessage('Employee ID can only contain letters and numbers'),
  
  body('department')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Department must be between 2 and 100 characters'),
  
  body('phone')
    .isMobilePhone()
    .withMessage('Please provide a valid phone number')
];

/**
 * Validation rules for room management
 */
const validateRoom = [
  body('roomNumber')
    .trim()
    .isLength({ min: 1, max: 20 })
    .withMessage('Room number is required and must be less than 20 characters'),
  
  body('building')
    .trim()
    .isLength({ min: 1, max: 50 })
    .withMessage('Building name is required and must be less than 50 characters'),
  
  body('capacity')
    .isInt({ min: 1, max: 10 })
    .withMessage('Capacity must be a number between 1 and 10'),
  
  body('floor')
    .isInt({ min: 0, max: 20 })
    .withMessage('Floor must be a number between 0 and 20'),
  
  body('roomType')
    .isIn(['single', 'double', 'triple', 'quad'])
    .withMessage('Room type must be single, double, triple, or quad'),
  
  body('rent')
    .isFloat({ min: 0 })
    .withMessage('Rent must be a positive number'),
  
  body('amenities')
    .optional()
    .isArray()
    .withMessage('Amenities must be an array')
];

/**
 * Validation rules for gate pass
 */
const validateGatePass = [
  body('reason')
    .trim()
    .isLength({ min: 10, max: 500 })
    .withMessage('Reason must be between 10 and 500 characters'),
  
  body('destination')
    .trim()
    .isLength({ min: 2, max: 100 })
    .withMessage('Destination must be between 2 and 100 characters'),
  
  body('departureTime')
    .isISO8601()
    .withMessage('Please provide a valid departure time'),
  
  body('expectedReturnTime')
    .isISO8601()
    .withMessage('Please provide a valid expected return time'),
  
  body('emergencyContact')
    .optional()
    .isMobilePhone()
    .withMessage('Please provide a valid emergency contact number')
];

/**
 * Validation rules for complaints
 */
const validateComplaint = [
  body('subject')
    .trim()
    .isLength({ min: 5, max: 200 })
    .withMessage('Subject must be between 5 and 200 characters'),
  
  body('description')
    .trim()
    .isLength({ min: 20, max: 1000 })
    .withMessage('Description must be between 20 and 1000 characters'),
  
  body('category')
    .isIn(['maintenance', 'security', 'hygiene', 'noise', 'other'])
    .withMessage('Category must be maintenance, security, hygiene, noise, or other'),
  
  body('priority')
    .optional()
    .isIn(['low', 'medium', 'high', 'urgent'])
    .withMessage('Priority must be low, medium, high, or urgent')
];

/**
 * Validation rules for fines
 */
const validateFine = [
  body('studentId')
    .trim()
    .isLength({ min: 1 })
    .withMessage('Student ID is required'),
  
  body('reason')
    .trim()
    .isLength({ min: 5, max: 500 })
    .withMessage('Reason must be between 5 and 500 characters'),
  
  body('amount')
    .isFloat({ min: 0 })
    .withMessage('Amount must be a positive number'),
  
  body('fineType')
    .isIn(['late_return', 'damage', 'violation', 'other'])
    .withMessage('Fine type must be late_return, damage, violation, or other')
];

/**
 * Validation rules for payments
 */
const validatePayment = [
  body('studentId')
    .trim()
    .isLength({ min: 1 })
    .withMessage('Student ID is required'),
  
  body('amount')
    .isFloat({ min: 0 })
    .withMessage('Amount must be a positive number'),
  
  body('paymentType')
    .isIn(['rent', 'fine', 'deposit', 'other'])
    .withMessage('Payment type must be rent, fine, deposit, or other'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ max: 200 })
    .withMessage('Description must be less than 200 characters')
];

/**
 * Validation rules for ID parameters
 */
const validateId = [
  param('id')
    .trim()
    .isLength({ min: 1 })
    .withMessage('ID is required')
];

/**
 * Validation rules for query parameters
 */
const validatePagination = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  
  query('sortBy')
    .optional()
    .trim()
    .isLength({ min: 1 })
    .withMessage('Sort field is required if provided'),
  
  query('sortOrder')
    .optional()
    .isIn(['asc', 'desc'])
    .withMessage('Sort order must be asc or desc')
];

/**
 * Validation rules for search queries
 */
const validateSearch = [
  query('search')
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Search term must be between 1 and 100 characters')
];

/**
 * Sanitize input data
 */
const sanitizeInput = (req, res, next) => {
  // Remove any potential XSS or injection attempts
  const sanitizeString = (str) => {
    if (typeof str !== 'string') return str;
    return str.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
              .replace(/javascript:/gi, '')
              .replace(/on\w+\s*=/gi, '');
  };

  const sanitizeObject = (obj) => {
    if (typeof obj !== 'object' || obj === null) return obj;
    
    const sanitized = {};
    for (const key in obj) {
      if (typeof obj[key] === 'string') {
        sanitized[key] = sanitizeString(obj[key]);
      } else if (typeof obj[key] === 'object') {
        sanitized[key] = sanitizeObject(obj[key]);
      } else {
        sanitized[key] = obj[key];
      }
    }
    return sanitized;
  };

  if (req.body) {
    req.body = sanitizeObject(req.body);
  }

  if (req.query) {
    req.query = sanitizeObject(req.query);
  }

  next();
};

module.exports = {
  validateUserRegistration,
  validateUserLogin,
  validateStudentRegistration,
  validateWardenRegistration,
  validateRoom,
  validateGatePass,
  validateComplaint,
  validateFine,
  validatePayment,
  validateId,
  validatePagination,
  validateSearch,
  sanitizeInput
};
