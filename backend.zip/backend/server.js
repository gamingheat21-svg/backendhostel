const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const dotenv = require('dotenv');
const path = require('path');

// Import database and error handling
const database = require('./config/db');
const { errorHandler, notFound } = require('./middlewares/errorHandler');

// Import routes
const authRoutes = require('./routes/auth.routes');
const studentsRoutes = require('./routes/students.routes');
const wardensRoutes = require('./routes/wardens.routes');
const roomsRoutes = require('./routes/rooms.routes');
const gatePassRoutes = require('./routes/gatepass.routes');
const complaintsRoutes = require('./routes/complaints.routes');
const finesRoutes = require('./routes/fines.routes');
const paymentsRoutes = require('./routes/payments.routes');

// Load environment variables
dotenv.config({ path: path.join(__dirname, 'config.env') });

// Create Express app
const app = express();

// Initialize database
database.init();

// Security middleware
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Logging middleware
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Server is running',
    data: {
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'development',
      version: '1.0.0'
    },
    errors: []
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/students', studentsRoutes);
app.use('/api/wardens', wardensRoutes);
app.use('/api/rooms', roomsRoutes);
app.use('/api/gatepasses', gatePassRoutes);
app.use('/api/complaints', complaintsRoutes);
app.use('/api/fines', finesRoutes);
app.use('/api/payments', paymentsRoutes);

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Hostel Management System API',
    data: {
      version: '1.0.0',
      description: 'A complete Node.js backend for Hostel Management System',
      endpoints: {
        auth: '/api/auth',
        students: '/api/students',
        wardens: '/api/wardens',
        rooms: '/api/rooms',
        gatepasses: '/api/gatepasses',
        complaints: '/api/complaints',
        fines: '/api/fines',
        payments: '/api/payments'
      },
      documentation: 'See README.md for detailed API documentation'
    },
    errors: []
  });
});

// Handle 404 errors
app.use(notFound);

// Global error handler
app.use(errorHandler);

// Start server
const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
  console.log(`
🚀 Hostel Management System Server Started!
📍 Server running on port ${PORT}
🌍 Environment: ${process.env.NODE_ENV || 'development'}
📊 Database: JSON file (lowdb)
🔗 API Base URL: http://localhost:${PORT}/api
📖 Health Check: http://localhost:${PORT}/health

Available endpoints:
• Authentication: /api/auth
• Students: /api/students  
• Wardens: /api/wardens
• Rooms: /api/rooms
• Gate Passes: /api/gatepasses
• Complaints: /api/complaints
• Fines: /api/fines
• Payments: /api/payments

Press Ctrl+C to stop the server
  `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('Process terminated');
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received. Shutting down gracefully...');
  server.close(() => {
    console.log('Process terminated');
  });
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
  console.error('Unhandled Promise Rejection:', err.message);
  // Close server & exit process
  server.close(() => {
    process.exit(1);
  });
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err.message);
  console.error(err.stack);
  process.exit(1);
});

module.exports = app;
